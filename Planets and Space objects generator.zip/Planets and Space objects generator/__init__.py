#-------------------------------------------------#
#                   __init__.py                   #
# Soubor pro inicializaci addonu a jeho  obnovení #
#                   Marek Hlávka                  #
#      Addon pro generování vesmírných objektů    #
#-------------------------------------------------#
bl_info = {
    'name': 'Planets and Space objects generator',
    'category': 'Add Mesh',
    'author': 'Marek Hlavka',
    'version': (0, 0, 1),
    'blender': (2, 93, 0)
}

modulesNames = [
    'general.plain_sphere',
    'general.planet_noise',
    'sphere.plain_object',
    'sphere.triangle_division',
    'general.water_border',
    'general.ring',
    'general.clouds',
    'general.color_planet',
    'ui.planet_panel',
    'ui.ui_menu',
    'ui.background_panel',
    'ui.panels.galaxy_panel',
    'ui.panels.nebula_panel',
    'ui.panels.bh_panel',
    'ui.panels.moon_panel',
    'ui.panels.asteroid_panel',
    'ui.panels.ring_panel',
    'ui.panels.clouds_panel',
    'ui.panels.gas_panel',
    'ui.panels.planet_panel',
    'ui.panels.sun_panel',
    'craters.craters',
    'other_obj.sun_object',
    'other_obj.moon_object',
    'other_obj.galaxy',
    'other_obj.black_hole',
    'other_obj.nebula',
    'other_obj.asteroid',
    'other_obj.asteroid_field',
    'other_obj.gas_giant',
    'operators.background',
    'operators.compositing',
    'operators.bh_utils_ops',
    'settings.my_node_tree'
]

import sys
import importlib

modulesFullNames = []
for currentModuleName in modulesNames:
    modulesFullNames.append('{}.{}'.format(__name__, currentModuleName))

for currentModuleFullName in modulesFullNames:
    if currentModuleFullName in sys.modules:
        importlib.reload(sys.modules[currentModuleFullName])
    else:
        globals()[currentModuleFullName] = importlib.import_module(currentModuleFullName)
        setattr(globals()[currentModuleFullName], 'modulesNames', modulesFullNames)

def register():
    for currentModuleName in modulesFullNames:
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'register'):
                sys.modules[currentModuleName].register()

def unregister():
    for currentModuleName in modulesFullNames:
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'unregister'):
                sys.modules[currentModuleName].unregister()