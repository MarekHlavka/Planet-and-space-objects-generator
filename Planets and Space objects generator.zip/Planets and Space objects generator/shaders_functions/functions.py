import bpy

# Function for mixing RGB from more than one input
class MultiMixRGB:
    output = None
    inputs_vals = []
    inputs_facts = []

    def __init__(self, x, y, nodes, links, levels, mode):
        
        done_levels = 0
        prev_output = None

        while done_levels < levels:
            
            mixRGB = nodes.new('ShaderNodeMixRGB')
            mixRGB.location = (x + (done_levels * 200), y - (done_levels * 200))
            mixRGB.blend_type = (mode)
            
            self.inputs_facts.append(mixRGB.inputs[0])
            if done_levels == 0:
                self.inputs_vals.append(mixRGB.inputs[1])
            else:
                links.new(prev_output, mixRGB.inputs[1])
            self.inputs_vals.append(mixRGB.inputs[2])
            prev_output = mixRGB.outputs[0]

            done_levels = done_levels + 1
            print("hello")


        self.output = prev_output
        


    def get_output(self):
        return self.output

    def get_inputs_vals(self):
        return self.inputs_vals

    def get_inputs_facts(self):
        return self.inputs_facts