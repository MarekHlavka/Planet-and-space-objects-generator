import bpy
from ...settings import settings
from ...sphere import plain_object
from . import sun_surface
from bpy_extras.object_utils import object_data_add, AddObjectHelper

class MESH_OT_sun_basic(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.sun_basic"
    bl_label = "Add basic sun"
    bl_options = {'REGISTER', 'UNDO'}

    detail_level: bpy.props.IntProperty(
        name="Level of detail",
        description="Determines how many faces is in the mesh",
        default = 30,
        min = 0,
        soft_max = 100,
        max = 1000
    )

    radius: bpy.props.FloatProperty(
        name="Radius",
        description="Radius of planet",
        default = 10.0,
        min = 0.1,
        soft_max = 100
    )

    def execute(self, context):
        cube = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Star")

        settings.set_cycles()

        """
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas: # iterate through areas in current screen
                if area.type == 'VIEW_3D':
                    for space in area.spaces: # iterate through spaces in current VIEW_3D area
                        if space.type == 'VIEW_3D': # check if space is a 3D view
                            space.shading.type = 'RENDERED'
        """

        cube.resize(self.detail_level)
        cube.project_to_sphere(self.radius)

        mesh.from_pydata(cube.vertices, cube.edges, cube.faces)
        object_data_add(context, mesh, operator=self)
        mesh = context.object.data
        
        for f in mesh.polygons:
            f.use_smooth = True
        
        obj = context.active_object
        mesh = obj.data

        bpy.ops.object.mode_set(mode = 'OBJECT')
        sun_surface.sun_surface(mesh)

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        light_radius = self.radius
        #sun_surface.light(obj, light_radius)

        return{'FINISHED'}

def add_operator(self, context):
    self.layout.operator(MESH_OT_sun_basic.bl_idname)


def register():
    bpy.utils.register_class(MESH_OT_sun_basic)

def unregister():
    bpy.utils.unregister_class(MESH_OT_sun_basic)