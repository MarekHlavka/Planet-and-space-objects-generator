
import bpy
from ...settings.my_node_tree import MyNodeTree

def sun_surface(mesh):

    material = bpy.data.materials.new(name = "Sun_surface")
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    #region
    """
    principled_node = nodes.get('Principled BSDF')
    vector_add = nodes.new('ShaderNodeVectorMath')
    ramp_texture = nodes.new('ShaderNodeValToRGB')
    ramp_fresnel = nodes.new('ShaderNodeValToRGB')
    noise = nodes.new('ShaderNodeTexNoise')
    fresnel = nodes.new('ShaderNodeFresnel')

    principled_node.inputs[18].default_value = (10.5)

    #Vector Math
    vector_add.location = (-200,100)

    #Noise
    noise.location = (-700,300)
    noise.inputs[2].default_value = (85.0) #Scale
    noise.inputs[3].default_value = (7.5) #Detail
    noise.inputs[5].default_value = (-0.5) #Distortion

    #Ramp noise
    ramp_texture.location = (-500,300)
    ramp_texture.color_ramp.elements.new(0.550)

    ramp_texture.color_ramp.elements[0].color = (0,0,0,1)
    ramp_texture.color_ramp.elements[0].position = (0.4)
    ramp_texture.color_ramp.elements[1].color = (0.95,0.45,0,1)
    ramp_texture.color_ramp.elements[2].color = (1,0,0,1)
    ramp_texture.name = ('Object color')

    #Fresnel
    fresnel.location = (-700, -100)

    #Ramp fresnel
    ramp_fresnel.location = (-500, -100)
    ramp_fresnel.color_ramp.interpolation = ('B_SPLINE')
    ramp_fresnel.color_ramp.elements[0].color = (0,0,0,1)
    ramp_fresnel.color_ramp.elements[0].position = (0.85)
    ramp_fresnel.color_ramp.elements[1].color = (0.4,0,0,1)

    #Linking
    links.new(vector_add.outputs[0], principled_node.inputs[17])

    links.new(ramp_texture.outputs[0], vector_add.inputs[0])
    links.new(ramp_fresnel.outputs[0], vector_add.inputs[1])

    links.new(noise.outputs[0], ramp_texture.inputs[0])
    links.new(fresnel.outputs[0], ramp_fresnel.inputs[0])
    """
    #endregion

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    # Level 1 ------------------------------------------------------
    msg_1 = nodes.new('ShaderNodeTexMusgrave')
    msg_1.location = (x - 1100, y + 300)
    msg_1.musgrave_dimensions = ('4D')
    msg_1.musgrave_type = ('MULTIFRACTAL')
    msg_1.inputs[2].default_value = 1.7 #Scale
    msg_1.inputs[3].default_value = 3.9 #Detail
    msg_1.inputs[4].default_value = 0.0 #Dimenssion
    msg_1.inputs[5].default_value = 1.8 #Lacunarity

    color_1 = nodes.new('ShaderNodeValToRGB')
    color_1.location = (x - 900, y + 300)
    color_1.color_ramp.interpolation = ('B_SPLINE')
    colors = color_1.color_ramp.elements
    colors.new(0.5)
    colors[0].position = (0.4)
    colors[0].color = (0,0,0,1)
    colors[1].color = (0.03, 0.09, 0.03, 1)
    colors[2].position = (0.6)
    colors[2].color = (0,0,0,1)

    emission_1 = nodes.new('ShaderNodeEmission')
    emission_1.location = (x - 600, y + 300)
    emission_1.inputs[1].default_value = 50.0

    # Links
    nds.my_link(msg_1, 0, color_1, 0)
    nds.my_link(color_1, 0, emission_1, 0)

    # Level 2 ------------------------------------------------------
    msg_2 = nodes.new('ShaderNodeTexMusgrave')
    msg_2.location = (x - 1100, y)
    msg_2.musgrave_dimensions = ('4D')
    msg_2.musgrave_type = ('MULTIFRACTAL')
    msg_2.inputs[2].default_value = 3.0     #Scale 
    msg_2.inputs[3].default_value = 16.0    #Detail
    msg_2.inputs[4].default_value = 0.0     #Dimenssion
    msg_2.inputs[5].default_value = 2.0     #Lacunarity

    color_2 = nodes.new('ShaderNodeValToRGB')
    color_2.location = (x - 900, y)
    colors = color_2.color_ramp.elements
    colors.new(0.8)
    colors[0].position = (0.3)
    colors[0].color = (0,0,0,1)
    colors[1].color = (0.1, 0.01, 0.01, 1)
    colors[2].color = (0.23,0.23,0.23,1)

    emission_2 = nodes.new('ShaderNodeEmission')
    emission_2.location = (x - 600, y)
    emission_2.inputs[1].default_value = 55.0

    # Links
    nds.my_link(msg_2, 0, color_2, 0)
    nds.my_link(color_2, 0, emission_2, 0)

    # Level 3 ------------------------------------------------------
    msg_3 = nodes.new('ShaderNodeTexMusgrave')
    msg_3.location = (x - 1100, y - 300)
    msg_3.musgrave_dimensions = ('4D')
    msg_3.musgrave_type = ('MULTIFRACTAL')
    msg_3.inputs[2].default_value = 100.0   #Scale 
    msg_3.inputs[3].default_value = 16.0    #Detail
    msg_3.inputs[4].default_value = 0.2     #Dimenssion
    msg_3.inputs[5].default_value = 15.0    #Lacunarity

    color_3 = nodes.new('ShaderNodeValToRGB')
    color_3.location = (x - 900, y - 300)
    colors = color_3.color_ramp.elements
    colors[0].position = (0.4)
    colors[0].color = (0,0,0,1)
    colors[1].position = (0.6)
    colors[1].color = (0,0,0.15,1)

    emission_3 = nodes.new('ShaderNodeEmission')
    emission_3.location = (x - 600, y - 300)
    emission_3.inputs[1].default_value = 55.0

    # Links
    nds.my_link(msg_3, 0, color_3, 0)
    nds.my_link(color_3, 0, emission_3, 0)

    # Connection to output
    mix_1 = nodes.new('ShaderNodeMixShader')
    mix_1.location = (x - 400, y - 100)

    mix_2 = nodes.new('ShaderNodeMixShader')
    mix_2.location = (x - 200, y + 200)

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    nds.my_link(emission_2, 0, mix_1, 1)
    nds.my_link(emission_3, 0, mix_1, 2)
    nds.my_link(emission_1, 0, mix_2, 1)
    nds.my_link(mix_1, 0, mix_2, 2)
    nds.my_link(mix_2, 0, output, 0)

    

def light(obj, radius):

    light_data = bpy.data.lights.new(name="myLight", type='POINT')
    light_data.energy = 250000
    light_data.shadow_soft_size = radius * 1.1

    light_object = bpy.data.objects.new(name="myLight", object_data=light_data)

    bpy.context.collection.objects.link(light_object)
    bpy.context.view_layer.objects.active = light_object
    light_object.location = obj.location