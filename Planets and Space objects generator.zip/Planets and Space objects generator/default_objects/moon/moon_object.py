import random
import bpy
from ...sphere import plain_object
from ...craters import craters
from bpy_extras.object_utils import object_data_add, AddObjectHelper

class MESH_OT_moon_object(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.moon_basic"
    bl_label = "Add basic moon"
    bl_options = {'REGISTER', 'UNDO'}

    detail_level: bpy.props.IntProperty(
        name="Level of detail",
        description="Determines how many faces is in the mesh",
        default = 30,
        min = 0,
        soft_max = 100,
        max = 1000
    )

    radius: bpy.props.FloatProperty(
        name="Radius",
        description="Radius of planet",
        default = 10.0,
        min = 0.1,
        soft_max = 100
    )

    seed: bpy.props.FloatProperty(
        name="Seed",
        default = 1
    )

    count: bpy.props.IntProperty(
        name="Crater count",
        default = 1,
        min = 0
    )

    craters_size: bpy.props.IntProperty(
        name="Size of craters",
        default = 10,
        min = 0,
        soft_max = 100,
        max = 1000
    )

    def execute(self, context):
        cube = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Moon")

        cube.resize(self.detail_level)
        cube.project_to_sphere(self.radius)

        craters_objects = craters.create_random_craters(self.count, self.seed, cube.vertices, 10, self.radius, self.craters_size)
        moon_verts = []
        for vertex in cube.vertices:
            change = craters.calcHeight(vertex, craters_objects)
            if change != 1:
                moon_verts.append(cube.change_height(vertex, change, None))
            else:
                moon_verts.append(vertex)

        mesh.from_pydata(moon_verts, cube.edges, cube.faces)
        object_data_add(context, mesh, operator=self)
        mesh = context.object.data
        
        for f in mesh.polygons:
            f.use_smooth = True
        return {'FINISHED'}


def add_operator(self, context):
    self.layout.operator(MESH_OT_moon_object.bl_idname)


def register():
    bpy.utils.register_class(MESH_OT_moon_object)

def unregister():
    bpy.utils.unregister_class(MESH_OT_moon_object)