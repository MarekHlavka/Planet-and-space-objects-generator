from typing import List
from mathutils import Vector
import random
import math


def create_random_craters(number, seed, verts, distribution, radius, craters_size) -> List:
    crater_objects = []
    random.seed(seed)
    
    for i in range(0, number):
        size = min(craters_size * random.expovariate(distribution), 10)
        crater_objects.append(Crater(size, random.choice(verts), radius))

    return crater_objects

def calcHeight(vertex, crater_objects):
    min_height = 1

    for crater in crater_objects:
        change = crater.calculate_height(vertex)
        min_height = min_height * change
            
    return min_height

# Calculate height based on distance from each crater center
class Crater():

    round_value = 1

    def __init__(self, in_crater_width, vertex, radius):
        self.crater_width = max(in_crater_width, 1)
        self.floor_height = self.crater_width / (-20)
        self.rim_width = self.crater_width / 5
        self.rim_steepnes = self.crater_width / 100
        self.border = max(1, 1 + self.rim_width)
        self.center = vertex
        self.sphere_radius = radius

    def crater_wall(self, dist):
        return ((dist * dist) - (2*self.crater_width*self.crater_width/self.sphere_radius))/self.crater_width

    def crater_floor(self):
        return self.floor_height/self.sphere_radius

    def crater_rim(self, dist):
        x = abs(dist) - (2*self.crater_width)
        return (self.rim_steepnes * x * x)/(self.crater_width*self.crater_width)

    def calculate_height(self,vertex):
        angle = vertex.angle(self.center)
        if angle == 0:
            angle_dist = 0
        else:
            angle_dist = abs(angle / (2*math.pi))


        sphere_perim = 2 * math.pi * self.sphere_radius
        dist = sphere_perim * angle_dist
        if dist > (2*self.crater_width):
            return 1
        return 1 + max(min(self.crater_wall(dist), self.crater_rim(dist)), self.crater_floor())