class MyNodeTree():

    def __init__(self, nodes, links):
        self.nodes = nodes
        self.links = links

    def get_nodes(self):
        return self.nodes

    def get_links(self):
        return self.links

    def my_link(self, output_node, output_index, input_node, input_index):

        
        if output_index == -1:
            first = output_node
            
        else:
            first = output_node.outputs[output_index]

        if input_index == -1:
            second = input_node
            
        else:
            second = input_node.inputs[input_index]

        self.links.new(first, second)
        

    def clear_nodes(self):
        for node in self.nodes:
            self.nodes.remove(node)

def register():
    pass

def unregister():
    pass
    
