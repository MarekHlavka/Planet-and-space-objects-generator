import bpy


def set_cycles():
    bpy.context.scene.render.engine = 'CYCLES'

def get_object_name(obj):
    if obj is None:
        return obj
    return obj.name.split(".")[0]