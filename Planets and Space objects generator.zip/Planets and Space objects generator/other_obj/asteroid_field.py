
import bpy
import random
from bpy_extras.object_utils import AddObjectHelper
from ..settings.my_node_tree import MyNodeTree

def resize(x, dimension):
    return max(-dimension,min(x * dimension, dimension))

def turn_off_reflection(obj):
    obj.visible_diffuse = False
    obj.visible_glossy = False
    obj.visible_transmission = False
    obj.visible_volume_scatter = False
    obj.visible_shadow = True

def surface():

    material = bpy.data.materials.new(name = "asteroid_field_material")
    material.use_nodes = True
    

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1000, y)

    noise_normal = nodes.new('ShaderNodeTexNoise')
    noise_normal.location = (x - 800, y - 400)
    noise_normal.inputs[2].default_value = 1.2
    noise_normal.inputs[3].default_value = 5.0
    noise_normal.inputs[4].default_value = 0.59
    noise_normal.inputs[5].default_value = 0.0

    noise_color = nodes.new('ShaderNodeTexNoise')
    noise_color.location = (x - 800, y)
    noise_color.noise_dimensions = ('4D')
    noise_color.inputs[2].default_value = 0.3
    noise_color.inputs[3].default_value = 5.0
    noise_color.inputs[4].default_value = 0.59
    noise_color.inputs[5].default_value = 0.0
    noise_color.name = ('noise_color')

    bump = nodes.new('ShaderNodeBump')
    bump.location = (x - 600, y - 400)
    bump.inputs[0].default_value = 0.89
    bump.inputs[1].default_value = 0.6
    bump.name = ('bump_normals')

    color_color = nodes.new('ShaderNodeValToRGB')
    color_color.location = (x - 600, y)
    color_color.color_ramp.elements[1].color = (0.25, 0.25, 0.25, 1)
    color_color.name = ('Object color')

    principled = nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (x - 300, y)
    principled.inputs[7].default_value = 0.0

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    nds.my_link(tex_coord, 3, noise_normal, 0)
    nds.my_link(noise_normal, 0, bump, 2)
    nds.my_link(tex_coord, 3, noise_color, 0)
    nds.my_link(noise_color, 0, color_color, 0)
    nds.my_link(bump, 0, principled, 22)
    nds.my_link(principled, 0, output, 0)
    nds.my_link(color_color, 0, principled, 0)

    return material

class MESH_OT_asteroid_field(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.asteroid_field"
    bl_label = "Asteroid field"
    bl_options = {'REGISTER', 'UNDO'}


    seed: bpy.props.FloatProperty(
        name="Seed",
        default = 1
    )

    count_ast: bpy.props.IntProperty(
        name="Count",
        default = 30
    )

    dimensions: bpy.props.FloatVectorProperty(
        name="Dimensions",
        default = (40.0, 40.0, 40.0),
        min = 1.0
    )

    surface: bpy.props.BoolProperty(
        name="Shared material",
        default=True
    )

    def execute(self, context):

        random.seed(self.seed)

        if self.surface:
            material = surface()
            pass


        for i in range(0, self.count_ast):
            loc_seed = random.random()
            factor = random.random() + 1

            x = random.gauss(0, self.dimensions[0])
            y = random.gauss(0, self.dimensions[1])
            z = random.gauss(0, self.dimensions[2])

            bpy.ops.mesh.asteroid_object(noise=factor, seed=loc_seed, location=(x,y,z), size=min(1.5, max(0.5,random.gauss(1, 0.2))))
            turn_off_reflection(context.active_object)

            if self.surface:
                context.active_object.data.materials[0] = material
                print(material)
                print(context.active_object.data.materials[0])
                pass



        return {'FINISHED'}


def register():
    bpy.utils.register_class(MESH_OT_asteroid_field)

def unregister():
    bpy.utils.unregister_class(MESH_OT_asteroid_field)