import bpy

def mat_blend_type(mat):
    mat.blend_method = 'BLEND'

def galaxy_material(mesh):

    material = bpy.data.materials.new(name = "Galaxy_surface")
    material.use_nodes = True
    mesh.materials.append(material)
    mat_blend_type(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nodes.remove(nodes.get('Principled BSDF')) # Delete default

    output = nodes.get('Material Output') # Material output

    principled_volume = nodes.new('ShaderNodeVolumePrincipled')
    principled_volume.location = (0, 300)
    principled_volume.inputs[2].default_value = (0.0)
    principled_volume.inputs[6].default_value = (1.0)
    links.new(principled_volume.outputs[0], output.inputs[1]) # Default link

    galaxy_size = 0.1

    # --------------------------------------------------------------
    # ------------- First group ---------------- Shape -------------
    # --------------------------------------------------------------
    #region
    y_level = 1200

    # Eliptic sphere
    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (-3000, y_level + 100)

    mapping = nodes.new('ShaderNodeMapping')
    mapping.location = (-2800, y_level)
    mapping.inputs[3].default_value = (galaxy_size, galaxy_size, 1.8)

    grad_tex = nodes.new('ShaderNodeTexGradient')
    grad_tex.location = (-2200, y_level - 300)
    grad_tex.gradient_type = ('SPHERICAL')

    # Rotation mask
    mapping_rot = nodes.new('ShaderNodeMapping')
    mapping_rot.location = (-1400, y_level)

    noise_rot = nodes.new('ShaderNodeTexNoise')
    noise_rot.location = (-1200, y_level)
    noise_rot.inputs[2].default_value = (0.2) ##### SHAPE OF GALAXY
    noise_rot.name = ('galaxy_shape')

    color_ramp_rot = nodes.new('ShaderNodeValToRGB')
    color_ramp_rot.location = (-1000, y_level)
    color_ramp_rot.color_ramp.elements[0].position = (0.5)

    rgb_mix_rot = nodes.new('ShaderNodeMixRGB')
    rgb_mix_rot.location = (-700, y_level-100)
    rgb_mix_rot.blend_type = ('MULTIPLY')
    rgb_mix_rot.inputs[0].default_value = (1.0)

    math_rot = nodes.new('ShaderNodeMath')
    math_rot.location = (-1800, y_level-100)
    math_rot.operation = ('MULTIPLY')
    math_rot.inputs[1].default_value = (3.0) ######### INPUT FOR ROTATION
    math_rot.name = ('galaxy_rotation')

    math_rot_2 = nodes.new('ShaderNodeMath')
    math_rot_2.location = (-2000, y_level-100)
    math_rot_2.operation = ('POWER')
    math_rot_2.inputs[1].default_value = (1.5) ########## INPUT FOR ROT FALLOFF
    math_rot_2.name = ('galaxy_rotation_falloff')

    combine_xyz_rot = nodes.new('ShaderNodeCombineXYZ')
    combine_xyz_rot.location = (-1600, y_level-100)

    # Galaxy center
    center_combine = nodes.new('ShaderNodeCombineXYZ')
    center_combine.location = (-3000, y_level - 600)
    center_combine.inputs[2].default_value = 1.0

    center_value = nodes.new('ShaderNodeValue')
    center_value.location = (-3400, y_level - 600)
    center_value.outputs[0].default_value = 15.0
    center_value.name = ('center_size')

    center_div = nodes.new('ShaderNodeMath')
    center_div.location = (-3200, y_level - 600)
    center_div.operation = ('DIVIDE')
    center_div.inputs[1].default_value = 100.0

    mapping_center = nodes.new('ShaderNodeMapping')
    mapping_center.location = (-2800, y_level - 400)
    mapping_center.inputs[3].default_value = (0.2, 0.2, 1.0) ####### SIZE OF CENTER

    grad_tex_center = nodes.new('ShaderNodeTexGradient')
    grad_tex_center.location = (-2600, y_level - 500)
    grad_tex_center.gradient_type = ('SPHERICAL')

    rgb_add = nodes.new('ShaderNodeMixRGB')
    rgb_add.location = (-500, y_level - 200)
    rgb_add.blend_type = ('ADD')
    rgb_add.inputs[0].default_value = (1.0)

    color_ramp_center = nodes.new('ShaderNodeValToRGB')
    color_ramp_center.location = (-2200, y_level - 500)
    color_ramp_center.color_ramp.interpolation = ('B_SPLINE')
    color_ramp_center.color_ramp.elements[0].position = (0.6)

    # Noise the spin
    noise_spin = nodes.new('ShaderNodeTexNoise')
    noise_spin.location = (-2600, y_level - 100)

    mix_spin = nodes.new('ShaderNodeMixRGB')
    mix_spin.location = (-2400, y_level - 300)
    mix_spin.blend_type = ('OVERLAY')
    mix_spin.inputs[0].default_value = (0.2) #### Effect of noise to spin
    mix_spin.name = ('spin_noise')

    # ----- Linkink group ------

    # Basic input
    links.new(tex_coord.outputs[3], mapping.inputs[0])
    

    # Rotation
    links.new(tex_coord.outputs[3], mapping_rot.inputs[0])
    links.new(grad_tex.outputs[0], math_rot_2.inputs[0])
    links.new(math_rot_2.outputs[0], math_rot.inputs[0])
    links.new(math_rot.outputs[0], combine_xyz_rot.inputs[2])
    links.new(combine_xyz_rot.outputs[0], mapping_rot.inputs[2])
    links.new(mapping_rot.outputs[0], noise_rot.inputs[0])
    links.new(noise_rot.outputs[0], color_ramp_rot.inputs[0])
    links.new(color_ramp_rot.outputs[0], rgb_mix_rot.inputs[1])
    links.new(grad_tex.outputs[0], rgb_mix_rot.inputs[2])

    # Center
    links.new(center_value.outputs[0], center_div.inputs[0])
    links.new(center_div.outputs[0], center_combine.inputs[0])
    links.new(center_div.outputs[0], center_combine.inputs[1])
    links.new(center_combine.outputs[0], mapping_center.inputs[3])
    links.new(tex_coord.outputs[3], mapping_center.inputs[0])
    links.new(mapping_center.outputs[0], grad_tex_center.inputs[0])
    links.new(grad_tex_center.outputs[0], color_ramp_center.inputs[0])
    links.new(color_ramp_center.outputs[0], rgb_add.inputs[2])

    # Spin
    links.new(mapping.outputs[0], mix_spin.inputs[1])
    links.new(mix_spin.outputs[0], grad_tex.inputs[0])
    links.new(noise_spin.outputs[0], mix_spin.inputs[2])

    links.new(rgb_mix_rot.outputs[0], rgb_add.inputs[1])
    first_output = rgb_add.outputs[0]
    #endregion


    # --------------------------------------------------------------
    # ------------- Second group ----------- Stars -----------------
    # --------------------------------------------------------------
    #region

    y_level = y_level - 1000

    tex_coord_2 = nodes.new('ShaderNodeTexCoord')
    tex_coord_2.location = (-3000, y_level)

    mapping_2 = nodes.new('ShaderNodeMapping')
    mapping_2.location = (-2800, y_level)

    voronai_big = nodes.new('ShaderNodeTexVoronoi')
    voronai_big.location = (-2600, y_level)
    voronai_big.inputs[2].default_value = (1.2) ##### SIZE OF BIG STARS
    voronai_big.name = ('big_stars_size')

    voronai_small = nodes.new('ShaderNodeTexVoronoi')
    voronai_small.location = (-2600, y_level - 300)
    voronai_small.inputs[2].default_value = (3.0) ##### SIZE OF SMALL STARS
    voronai_small.name = ('small_stars_size')

    color_ramp_big = nodes.new('ShaderNodeValToRGB')
    color_ramp_big.location = (-2400, y_level)
    color_ramp_big.color_ramp.interpolation = ('CONSTANT')
    color_ramp_big.color_ramp.color_mode = ('HSV')
    color_ramp_big.color_ramp.elements[1].color = (0,0,0,1)
    color_ramp_big.color_ramp.elements[0].color = (20,20,20,20)
    color_ramp_big.color_ramp.elements[1].position = (0.04) ##### NOF BIG STARS
    color_ramp_big.name = ('big_stars_nof')

    color_ramp_small = nodes.new('ShaderNodeValToRGB')
    color_ramp_small.location = (-2400, y_level - 300)
    color_ramp_small.color_ramp.interpolation = ('CONSTANT')
    color_ramp_small.color_ramp.color_mode = ('HSV')
    color_ramp_small.color_ramp.elements[1].color = (0,0,0,1)
    color_ramp_small.color_ramp.elements[0].color = (20,20,20,20)
    color_ramp_small.color_ramp.elements[1].position = (0.05) ##### NOF SMALL STARS
    color_ramp_small.name = ('small_stars_nof')

    stars_add = nodes.new('ShaderNodeMixRGB')
    stars_add.location = (-2100, y_level)
    stars_add.blend_type = ('ADD')
    stars_add.inputs[0].default_value = (1.0)

    stars_circle = nodes.new('ShaderNodeMixRGB')
    stars_circle.location = (-800, y_level)
    stars_circle.blend_type = ('MULTIPLY')
    stars_circle.inputs[0].default_value = (1.0)


    # Links
    links.new(tex_coord_2.outputs[3], mapping_2.inputs[0])

    links.new(mapping_2.outputs[0], voronai_big.inputs[0])
    links.new(mapping_2.outputs[0], voronai_small.inputs[0])

    links.new(voronai_small.outputs[0], color_ramp_small.inputs[0])
    links.new(voronai_big.outputs[0], color_ramp_big.inputs[0])

    links.new(color_ramp_big.outputs[0], stars_add.inputs[1])
    links.new(color_ramp_small.outputs[0], stars_add.inputs[2])

    links.new(stars_add.outputs[0], stars_circle.inputs[1])
    links.new(first_output, stars_circle.inputs[2])

    second_output = stars_circle.outputs[0]

    #endregion


    # --------------------------------------------------------------
    # ------------- Third group ----------- Color ------------------
    # --------------------------------------------------------------
    #region
    y_level = y_level - 500

    tex_color = nodes.new('ShaderNodeTexCoord')
    tex_color.location = (-1600, y_level)

    mapping_color = nodes.new('ShaderNodeMapping')
    mapping_color.location = (-1400, y_level)
    mapping_color.inputs[3].default_value = (galaxy_size, galaxy_size, 1.8)

    grad_color = nodes.new('ShaderNodeTexGradient')
    grad_color.location = (-1200, y_level)
    grad_color.gradient_type = ('SPHERICAL')

    color_ramp_color = nodes.new('ShaderNodeValToRGB')
    color_ramp_color.location = (-1000, y_level)
    color_ramp_color.name = ('Object color')
    points = color_ramp_color.color_ramp.elements

    points.new(0.33)
    points.new(0.66)
    points[0].color = (1.0, 0.0, 0.0, 1.0)
    points[1].color = (0.0, 1.0, 0.0, 1.0)
    points[2].color = (0.0, 0.0, 1.0, 1.0)
    points[3].color = (1.0, 1.0, 0.0, 1.0)

    # Links
    links.new(tex_color.outputs[3], mapping_color.inputs[0])
    links.new(mapping_color.outputs[0], grad_color.inputs[0])
    links.new(grad_color.outputs[0], color_ramp_color.inputs[0])

    color_output = color_ramp_color.outputs[0]

    #endregion

    mix_groups = nodes.new('ShaderNodeMixRGB')
    mix_groups.location = (-600, y_level + 500)
    mix_groups.blend_type = ('ADD')
    mix_groups.inputs[0].default_value = (0.8)

    mix_color = nodes.new('ShaderNodeMixRGB')
    mix_color.location = (-200, y_level + 500)
    mix_color.blend_type = ('MULTIPLY')
    mix_color.inputs[0].default_value = (1.0)

    mix_dodge = nodes.new('ShaderNodeMixRGB')
    mix_dodge.location = (-400, y_level + 500)
    mix_dodge.blend_type = ('DODGE')
    mix_dodge.inputs[0].default_value = (1.0)

    # Groups output links

    links.new(first_output, mix_groups.inputs[1])
    links.new(second_output, mix_groups.inputs[2])

    links.new(mix_groups.outputs[0], mix_dodge.inputs[1]) 
    links.new(grad_color.outputs[0], mix_dodge.inputs[2])

    links.new(mix_dodge.outputs[0], mix_color.inputs[1])
    links.new(color_output, mix_color.inputs[2])
    links.new(mix_color.outputs[0], principled_volume.inputs[7])

    pass

class MESH_OT_galaxy(bpy.types.Operator):
    bl_idname = "mesh.galaxy"
    bl_label = "Add galaxy"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.mesh.primitive_cube_add(scale = (12.0, 12.0, 1.0))
        obj = context.active_object
        obj['type'] = "galaxy"
        mesh = obj.data
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        galaxy_material(mesh)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        return {'FINISHED'}

def add_operator(self, context):
    self.layout.operator(MESH_OT_galaxy.bl_idname)


def register():
    bpy.utils.register_class(MESH_OT_galaxy)

def unregister():
    bpy.utils.unregister_class(MESH_OT_galaxy)