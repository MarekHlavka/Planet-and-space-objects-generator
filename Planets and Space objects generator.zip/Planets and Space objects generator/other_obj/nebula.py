import bpy
from ..settings import settings

def material_func(mesh):

    material = bpy.data.materials.new(name = "Nebula")
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    for node in nodes:
        nodes.remove(node)

    x = 0
    y = 0

    # Texture input ------------------------
    
    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 2200, y - 200)

    # Shape simple  ------------------------

    shape_mapping = nodes.new('ShaderNodeMapping')
    shape_mapping.location = (x - 2000, y)

    shape_grad_tex = nodes.new('ShaderNodeTexGradient')
    shape_grad_tex.location = (x - 1600, y)
    shape_grad_tex.gradient_type = ('SPHERICAL')

    # Links
    links.new(tex_coord.outputs[3], shape_mapping.inputs[0])
    links.new(shape_mapping.outputs[0], shape_grad_tex.inputs[0])
    shape_simple_out = shape_grad_tex.outputs[0]
    

    # Edges --------------------------------
    edges_noise = nodes.new('ShaderNodeTexNoise')
    edges_noise.location = (x - 1600, y - 300)
    edges_noise.inputs[4].default_value = 0.9
    edges_noise.name = ('edges_noise')

    edges_color = nodes.new('ShaderNodeValToRGB')
    edges_color.location = (x - 1400, y - 300)
    edges_color.color_ramp.elements[0].position = (0.45)
    edges_color.color_ramp.elements[1].position = (0.75)
    edges_color.name = ('edges_color')

    edges_mult = nodes.new('ShaderNodeMath')
    edges_mult.location = (x - 1100, y - 300)
    edges_mult.operation = ('MULTIPLY')
    edges_mult.inputs[1].default_value = 3.0

    # Links
    links.new(edges_noise.outputs[0], edges_color.inputs[0])
    links.new(edges_color.outputs[0], edges_mult.inputs[0])
    edges_out = edges_mult.outputs[0]

    # Shape mult ---------------------------
    main_noise_tex = nodes.new('ShaderNodeTexNoise')
    main_noise_tex.location = (x - 2000, y - 600)
    main_noise_tex.inputs[2].default_value = 1.9
    main_noise_tex.inputs[3].default_value = 8.0
    main_noise_tex.inputs[4].default_value = 0.683
    main_noise_tex.name = ('main_noise')

    main_mapping = nodes.new('ShaderNodeMapping')
    main_mapping.location = (x - 1800, y - 600)
    main_mapping.vector_type = ('TEXTURE')
    main_mapping.name = ('main_mapping')

    main_noise_shape = nodes.new('ShaderNodeTexNoise')
    main_noise_shape.location = (x - 1600, y - 600)
    main_noise_shape.inputs[2].default_value = 3.9
    main_noise_shape.inputs[3].default_value = 0.9
    main_noise_shape.inputs[4].default_value = 0.625

    main_color = nodes.new('ShaderNodeValToRGB')
    main_color.location = (x - 1400, y - 600)
    main_color.color_ramp.elements[0].position = (0.5)
    main_color.name = ('main_color')

    main_mult = nodes.new('ShaderNodeMath')
    main_mult.location = (x - 1100, y - 600)
    main_mult.operation = ('MULTIPLY')
    main_mult.inputs[1].default_value = 5.0

    main_seed = nodes.new('ShaderNodeCombineXYZ')
    main_seed.location = (x - 2000, y - 900)

    # Links
    links.new(tex_coord.outputs[3], main_noise_tex.inputs[0])
    links.new(main_noise_tex.outputs[0], main_mapping.inputs[0])
    # links.new(main_seed.outputs[0], main_mapping.inputs[1])
    links.new(main_mapping.outputs[0], main_noise_shape.inputs[0])
    links.new(main_noise_shape.outputs[0], main_color.inputs[0])
    links.new(main_color.outputs[0], main_mult.inputs[0])
    main_out = main_mult.outputs[0]

    # Color --------------------------------

    color_mult = nodes.new('ShaderNodeMath')
    color_mult.location = (x - 500, y + 300)
    color_mult.operation = ('MULTIPLY')
    color_mult.inputs[1].default_value = 1.5

    color_color = nodes.new('ShaderNodeValToRGB')
    color_color.location = (x - 300, y + 300)
    color_color.name = ('Object color')

    # Links
    links.new(color_mult.outputs[0], color_color.inputs[0])
    color_in = color_mult.inputs[0]
    color_out = color_color.outputs[0]

    # Output -------------------------------

    out_math_1 = nodes.new('ShaderNodeMath')
    out_math_1.location = (x - 900, y)
    out_math_1.operation = ('SUBTRACT')

    out_math_2 = nodes.new('ShaderNodeMath')
    out_math_2.location = (x - 700, y)
    out_math_2.operation = ('MULTIPLY')

    out_math_3 = nodes.new('ShaderNodeMath')
    out_math_3.location = (x - 200, y)
    out_math_3.operation = ('MULTIPLY')
    out_math_3.inputs[1].default_value = 5.0

    principled = nodes.new('ShaderNodeVolumePrincipled')
    principled.location = (x, y)
    
    out_mat = nodes.new('ShaderNodeOutputMaterial')
    out_mat.location = (x + 400, y)

    # Links
    links.new(out_math_1.outputs[0], out_math_2.inputs[0])
    links.new(out_math_2.outputs[0], out_math_3.inputs[0])
    links.new(out_math_3.outputs[0], principled.inputs[2])
    links.new(out_math_3.outputs[0], principled.inputs[6])
    links.new(principled.outputs[0], out_mat.inputs[1])
    links.new(shape_simple_out, out_math_1.inputs[0])
    links.new(edges_out, out_math_1.inputs[1])
    links.new(main_out, out_math_2.inputs[1])
    links.new(out_math_1.outputs[0], color_in)
    links.new(color_out, principled.inputs[0])
    links.new(color_out, principled.inputs[7])


class MESH_OT_nebula(bpy.types.Operator):
    bl_idname = "mesh.nebula"
    bl_label = "Add nebula"
    bl_option = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings.set_cycles()

        bpy.ops.mesh.primitive_cube_add()
        nebula = context.active_object
        nebula['type'] = "nebula"


        bpy.ops.object.mode_set(mode = 'OBJECT')
        material_func(nebula.data)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        nebula.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        return {'FINISHED'}

def add_operator(self, context):
    self.layout.operator(MESH_OT_nebula.bl_idname)

def register():
    bpy.utils.register_class(MESH_OT_nebula)

def unregister():
    bpy.utils.unregister_class(MESH_OT_nebula)     