import bpy
from ..sphere import plain_object
from ..craters import craters
from ..settings.my_node_tree import MyNodeTree
from bpy_extras.object_utils import object_data_add, AddObjectHelper

def surface(mesh, name):

    material = bpy.data.materials.new(name = "{}_gas_g_material".format(name))
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    # Rings -----------------------------------------------

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = ( x - 3500, y + 300)

    mapping = nodes.new('ShaderNodeMapping')
    mapping.location = (x - 3300, y + 300)

    separate = nodes.new('ShaderNodeSeparateXYZ')
    separate.location = (x - 3000, y + 300)

    absolute = nodes.new('ShaderNodeMath')
    absolute.location = ( x - 2800, y + 300)
    absolute.operation = ('ABSOLUTE')

    sine = nodes.new('ShaderNodeMath')
    sine.location = (x - 2600, y + 300)
    sine.operation = ('SINE')

    rings_add = nodes.new('ShaderNodeMath')
    rings_add.location = (x - 2400, y + 300)
    rings_add.operation = ('ADD')

    rings_range = nodes.new('ShaderNodeMapRange')
    rings_range.location = (x - 2200, y + 300)
    rings_range.inputs[1].default_value = -1.0

    rgb_curve = nodes.new('ShaderNodeRGBCurve')
    rgb_curve.location = (x - 2000, y + 300)
    rgb_curve.name = ('rgb_curve')

    texture_noise = nodes.new('ShaderNodeTexNoise')
    texture_noise.location = (x - 2800, y + 100)
    texture_noise.inputs[2].default_value = 10.0
    texture_noise.inputs[3].default_value = 1.0
    texture_noise.inputs[4].default_value = 0.5
    texture_noise.inputs[5].default_value = 1.8
    texture_noise.name = ('texture_noise')

    texture_range = nodes.new('ShaderNodeMapRange')
    texture_range.location = ( x - 2600, y + 100)
    texture_range.inputs[3].default_value = -0.25
    texture_range.inputs[4].default_value = 0.25

    # Links

    nds.my_link(tex_coord, 3, mapping, 0)
    nds.my_link(mapping, 0, separate, 0)
    nds.my_link(separate, 2, absolute, 0)
    nds.my_link(absolute, 0, sine, 0)
    nds.my_link(sine, 0, rings_add, 0)
    nds.my_link(rings_add, 0, rings_range, 0)
    nds.my_link(rings_range, 0, rgb_curve, 1)
    nds.my_link(texture_noise, 0, texture_range, 0)
    nds.my_link(texture_range, 0, rings_add, 1)

    rings_out = rgb_curve.outputs[0]

    # "Eyes" (Storms) -------------------------------------

    eye_voronoi = nodes.new('ShaderNodeTexVoronoi')
    eye_voronoi.location = (x - 3200, y - 300)
    eye_voronoi.voronoi_dimensions = ('4D')
    eye_voronoi.inputs[2].default_value = 2.5
    eye_voronoi.name = ('eye_voronoi')

    eye_noise = nodes.new('ShaderNodeTexNoise')
    eye_noise.location = (x - 3200, y - 600)
    eye_noise.inputs[2].default_value = 3.6
    eye_noise.inputs[3].default_value = 14.2
    eye_noise.inputs[4].default_value = 0.0
    eye_noise.inputs[5].default_value = 0.5
    eye_noise.name = ('eye_noise')

    eye_noise_range = nodes.new('ShaderNodeMapRange')
    eye_noise_range.location = ( x - 3000, y - 600)
    eye_noise_range.inputs[3].default_value = -0.25
    eye_noise_range.inputs[4].default_value = 0.25

    eye_add = nodes.new('ShaderNodeMath')
    eye_add.location = (x - 2800, y - 300)

    eye_color = nodes.new('ShaderNodeValToRGB')
    eye_color.location = (x - 2600, y - 300)
    eye_color.color_ramp.elements[0].position = 0.21
    eye_color.color_ramp.elements[1].position = 0.31
    eye_color.name = ('eye_color')

    eye_curve = nodes.new('ShaderNodeFloatCurve')
    eye_curve.location = (x - 2300, y - 300)
    eye_curve.mapping.curves[0].points[1].location = (0.98, 0.513)
    eye_curve.mapping.curves[0].points.new(0.94, 0.093)
    

    eye_range = nodes.new('ShaderNodeMapRange')
    eye_range.location = (x - 2000, y - 300)
    eye_range.inputs[4].default_value = 1.4
    eye_range.name = ('eye_range')

    # Links

    nds.my_link(eye_voronoi, 0, eye_add, 0)
    nds.my_link(eye_noise, 0, eye_noise_range, 0)
    nds.my_link(eye_noise_range, 0, eye_add, 1)
    nds.my_link(eye_add, 0, eye_color, 0)
    nds.my_link(eye_color, 0, eye_curve, 1)
    nds.my_link(eye_curve, 0, eye_range, 0)

    eye_out = eye_range.outputs[0]

    # Color -----------------------------------------------

    noise_color = nodes.new('ShaderNodeTexNoise')
    noise_color.location = (x - 1500, y)
    noise_color.inputs[4].default_value = 3.3

    color = nodes.new('ShaderNodeValToRGB')
    color.location = (x - 1000, y)
    color.name = ('Object color')

    fresnel_color = nodes.new('ShaderNodeValToRGB')
    fresnel_color.location = (x - 1000, y - 300)
    fresnel_color.color_ramp.interpolation = ('EASE')
    fresnel_color.color_ramp.elements[0].position = 0.72
    fresnel_color.color_ramp.elements[0].color = (1,1,1,1)
    fresnel_color.color_ramp.elements[1].color = (0,0,0,1)

    math_power = nodes.new('ShaderNodeMath')
    math_power.location = (x - 1000, y + 200)
    math_power.operation = ('POWER')
    math_power.inputs[1].default_value = 2.0

    layer_weight = nodes.new('ShaderNodeLayerWeight')
    layer_weight.location = (x - 1200, y + 200)

    mix = nodes.new('ShaderNodeMixRGB')
    mix.location = (x - 600, y)

    # Links 
    nds.my_link(rings_out, -1, noise_color, 0)
    nds.my_link(eye_out, -1, noise_color, 2)
    nds.my_link(noise_color, 0, color, 0)
    nds.my_link(layer_weight, 1, math_power, 0)
    nds.my_link(math_power, 0, mix, 0)
    nds.my_link(color, 0, mix, 1)
    nds.my_link(fresnel_color, 0, mix, 2)

    # Output

    principled = nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (x - 300, y)

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    # Links
    nds.my_link(mix, 0, principled, 0)
    nds.my_link(principled, 0, output, 0)






    


class MESH_OT_gas_giant(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.gas_giant"
    bl_label = "Moon"
    bl_options = {'REGISTER', 'UNDO'}

    radius: bpy.props.FloatProperty(
        name="Radius",
        description="Radius of planet",
        default = 10.0,
        min = 0.1,
        soft_max = 100
    )

    def execute(self, context):
        cube = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Gas giant")

        cube.resize(30)
        cube.project_to_sphere(self.radius)

        mesh.from_pydata(cube.vertices, cube.edges, cube.faces)
        object_data_add(context, mesh, operator=self)
        obj = context.active_object
        mesh = obj.data
        
        for f in mesh.polygons:
            f.use_smooth = True

        bpy.ops.object.mode_set(mode = 'OBJECT')
        surface(mesh, obj.name)

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        obj['type'] = "planet"

        obj['subtype'] = "gas_giant"

        obj['radius'] = self.radius

        context.active_object['ring'] = None

        context.active_object['clouds'] = None

        return {'FINISHED'}


def add_operator(self, context):
    self.layout.operator(MESH_OT_gas_giant.bl_idname)


def register():
    bpy.utils.register_class(MESH_OT_gas_giant)

def unregister():
    bpy.utils.unregister_class(MESH_OT_gas_giant)