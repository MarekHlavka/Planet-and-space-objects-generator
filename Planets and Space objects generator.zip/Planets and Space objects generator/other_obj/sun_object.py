import bpy
from ..settings import settings
from ..sphere import plain_object
from bpy_extras.object_utils import object_data_add, AddObjectHelper

import bpy
from ..settings.my_node_tree import MyNodeTree

def sun_surface(mesh):

    material = bpy.data.materials.new(name = "Sun_surface")
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    # Level 1 ------------------------------------------------------
    msg_1 = nodes.new('ShaderNodeTexMusgrave')
    msg_1.location = (x - 1100, y + 300)
    msg_1.musgrave_dimensions = ('4D')
    msg_1.musgrave_type = ('MULTIFRACTAL')
    msg_1.inputs[2].default_value = 1.7 #Scale
    msg_1.inputs[3].default_value = 3.9 #Detail
    msg_1.inputs[4].default_value = 0.0 #Dimenssion
    msg_1.inputs[5].default_value = 1.8 #Lacunarity
    msg_1.name = ('tex_1')

    color_1 = nodes.new('ShaderNodeValToRGB')
    color_1.location = (x - 900, y + 300)
    color_1.color_ramp.interpolation = ('B_SPLINE')
    colors = color_1.color_ramp.elements
    colors.new(0.5)
    colors[0].position = (0.4)
    colors[0].color = (0,0,0,1)
    colors[1].color = (0.03, 0.09, 0.03, 1)
    colors[2].position = (0.6)
    colors[2].color = (0,0,0,1)
    color_1.name = ('color_1')

    emission_1 = nodes.new('ShaderNodeEmission')
    emission_1.location = (x - 600, y + 300)
    emission_1.inputs[1].default_value = 50.0

    # Links
    nds.my_link(msg_1, 0, color_1, 0)
    nds.my_link(color_1, 0, emission_1, 0)

    # Level 2 ------------------------------------------------------
    msg_2 = nodes.new('ShaderNodeTexMusgrave')
    msg_2.location = (x - 1100, y)
    msg_2.musgrave_dimensions = ('4D')
    msg_2.musgrave_type = ('MULTIFRACTAL')
    msg_2.inputs[2].default_value = 3.0     #Scale 
    msg_2.inputs[3].default_value = 16.0    #Detail
    msg_2.inputs[4].default_value = 0.0     #Dimenssion
    msg_2.inputs[5].default_value = 2.0     #Lacunarity
    msg_2.name = ('tex_2')

    color_2 = nodes.new('ShaderNodeValToRGB')
    color_2.location = (x - 900, y)
    colors = color_2.color_ramp.elements
    colors.new(0.8)
    colors[0].position = (0.3)
    colors[0].color = (0,0,0,1)
    colors[1].color = (0.1, 0.01, 0.01, 1)
    colors[2].color = (0.23,0.23,0.23,1)
    color_2.name = ('color_2')

    emission_2 = nodes.new('ShaderNodeEmission')
    emission_2.location = (x - 600, y)
    emission_2.inputs[1].default_value = 55.0

    # Links
    nds.my_link(msg_2, 0, color_2, 0)
    nds.my_link(color_2, 0, emission_2, 0)

    # Level 3 ------------------------------------------------------
    msg_3 = nodes.new('ShaderNodeTexMusgrave')
    msg_3.location = (x - 1100, y - 300)
    msg_3.musgrave_dimensions = ('4D')
    msg_3.musgrave_type = ('MULTIFRACTAL')
    msg_3.inputs[2].default_value = 100.0   #Scale 
    msg_3.inputs[3].default_value = 16.0    #Detail
    msg_3.inputs[4].default_value = 0.2     #Dimenssion
    msg_3.inputs[5].default_value = 15.0    #Lacunarity
    msg_3.name = ('tex_3')

    color_3 = nodes.new('ShaderNodeValToRGB')
    color_3.location = (x - 900, y - 300)
    colors = color_3.color_ramp.elements
    colors[0].position = (0.4)
    colors[0].color = (0,0,0,1)
    colors[1].position = (0.6)
    colors[1].color = (0,0,0.15,1)
    color_3.name = ('color_3')

    emission_3 = nodes.new('ShaderNodeEmission')
    emission_3.location = (x - 600, y - 300)
    emission_3.inputs[1].default_value = 55.0

    # Links
    nds.my_link(msg_3, 0, color_3, 0)
    nds.my_link(color_3, 0, emission_3, 0)

    # Connection to output
    mix_1 = nodes.new('ShaderNodeMixShader')
    mix_1.location = (x - 400, y - 100)

    mix_2 = nodes.new('ShaderNodeMixShader')
    mix_2.location = (x - 200, y + 200)

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    nds.my_link(emission_2, 0, mix_1, 1)
    nds.my_link(emission_3, 0, mix_1, 2)
    nds.my_link(emission_1, 0, mix_2, 1)
    nds.my_link(mix_1, 0, mix_2, 2)
    nds.my_link(mix_2, 0, output, 0)

    

def light(obj, radius):

    light_data = bpy.data.lights.new(name="myLight", type='POINT')
    light_data.energy = 250000
    light_data.shadow_soft_size = radius * 1.1

    light_object = bpy.data.objects.new(name="myLight", object_data=light_data)

    bpy.context.collection.objects.link(light_object)
    bpy.context.view_layer.objects.active = light_object
    light_object.location = obj.location

class MESH_OT_sun_basic(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.sun_basic"
    bl_label = "Sun"
    bl_options = {'REGISTER', 'UNDO'}

    detail_level: bpy.props.IntProperty(
        name="Level of detail",
        description="Determines how many faces is in the mesh",
        default = 30,
        min = 0,
        soft_max = 100,
        max = 1000
    )

    radius: bpy.props.FloatProperty(
        name="Radius",
        description="Radius of planet",
        default = 10.0,
        min = 0.1,
        soft_max = 100
    )

    def execute(self, context):
        cube = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Star")

        settings.set_cycles()

        """
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas: # iterate through areas in current screen
                if area.type == 'VIEW_3D':
                    for space in area.spaces: # iterate through spaces in current VIEW_3D area
                        if space.type == 'VIEW_3D': # check if space is a 3D view
                            space.shading.type = 'RENDERED'
        """

        cube.resize(self.detail_level)
        cube.project_to_sphere(self.radius)

        mesh.from_pydata(cube.vertices, cube.edges, cube.faces)
        object_data_add(context, mesh, operator=self)
        mesh = context.object.data
        
        for f in mesh.polygons:
            f.use_smooth = True
        
        obj = context.active_object
        mesh = obj.data

        bpy.ops.object.mode_set(mode = 'OBJECT')
        sun_surface(mesh)

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        obj['type'] = "sun"

        obj['radius'] = self.radius
        #sun_surface.light(obj, light_radius)

        return{'FINISHED'}

def add_operator(self, context):
    self.layout.operator(MESH_OT_sun_basic.bl_idname)


def register():
    bpy.utils.register_class(MESH_OT_sun_basic)

def unregister():
    bpy.utils.unregister_class(MESH_OT_sun_basic)