from email.policy import default
import bpy
import random
from ..sphere import plain_object
from ..craters import craters
from ..settings.my_node_tree import MyNodeTree
from bpy_extras.object_utils import object_data_add, AddObjectHelper

from mathutils import Vector
from mathutils import noise

def asteroid_material(mesh, name):
    material = bpy.data.materials.new(name = "{}_asteroid_material".format(name))
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1000, y)

    noise_normal = nodes.new('ShaderNodeTexNoise')
    noise_normal.location = (x - 800, y - 400)
    noise_normal.inputs[2].default_value = 1.2
    noise_normal.inputs[3].default_value = 5.0
    noise_normal.inputs[4].default_value = 0.59
    noise_normal.inputs[5].default_value = 0.0

    noise_color = nodes.new('ShaderNodeTexNoise')
    noise_color.location = (x - 800, y)
    noise_color.noise_dimensions = ('4D')
    noise_color.inputs[2].default_value = 0.3
    noise_color.inputs[3].default_value = 5.0
    noise_color.inputs[4].default_value = 0.59
    noise_color.inputs[5].default_value = 0.0
    noise_color.name = ('noise_color')

    bump = nodes.new('ShaderNodeBump')
    bump.location = (x - 600, y - 400)
    bump.inputs[0].default_value = 0.89
    bump.inputs[1].default_value = 0.6
    bump.name = ('bump_normals')

    color_color = nodes.new('ShaderNodeValToRGB')
    color_color.location = (x - 600, y)
    color_color.color_ramp.elements[1].color = (0.25, 0.25, 0.25, 1)
    color_color.name = ('Object color')

    principled = nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (x - 300, y)
    principled.inputs[7].default_value = 0.0

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    nds.my_link(tex_coord, 3, noise_normal, 0)
    nds.my_link(noise_normal, 0, bump, 2)
    nds.my_link(tex_coord, 3, noise_color, 0)
    nds.my_link(noise_color, 0, color_color, 0)
    nds.my_link(bump, 0, principled, 22)
    nds.my_link(principled, 0, output, 0)
    nds.my_link(color_color, 0, principled, 0)

def asteroid_noise(vertices, factor, seed):
    new_verts = []

    random.seed(seed)
    offset = random.random()

    for vert in vertices:
        change = noise.noise(vert/10 + Vector((offset, offset, offset))) *2
        change = change + noise.noise(vert/5 - Vector((offset, offset, offset)))
        change = change + noise.noise(vert/2 + 0.3*Vector((offset, offset, offset))) *0.5
        
        new_verts.append(plain_object.plain_3D_object.change_height(None, vert, 1 + (change * factor / 10), 0))

    return new_verts


class MESH_OT_asteroid_object(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.asteroid_object"
    bl_label = "Asteroid"
    bl_options = {'REGISTER', 'UNDO'}

    noise: bpy.props.FloatProperty(
        name="Noise",
        description="Noise",
        default = 1.0,
        min = 0.1,
        soft_max = 4
    )

    seed: bpy.props.FloatProperty(
        name="Seed",
        default = 1
    )

    size: bpy.props.FloatProperty(
        name="Size",
        default = 1
    )

    def execute(self, context):
        cube = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Asteroid")

        cube.resize(30)
        cube.project_to_sphere(self.size*10)
        new_verts = asteroid_noise(cube.vertices, self.noise, self.seed)

        mesh.from_pydata(new_verts, cube.edges, cube.faces)
        object_data_add(context, mesh, operator=self)
        obj = context.active_object
        mesh = obj.data
        
        for f in mesh.polygons:
            f.use_smooth = True


        bpy.ops.object.mode_set(mode = 'OBJECT')
        asteroid_material(mesh, obj.name)

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        obj['type'] = "asteroid"

        return {'FINISHED'}


def register():
    bpy.utils.register_class(MESH_OT_asteroid_object)

def unregister():
    bpy.utils.unregister_class(MESH_OT_asteroid_object)