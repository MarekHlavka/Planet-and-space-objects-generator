import bpy
from ..sphere import plain_object
from ..craters import craters
from ..settings.my_node_tree import MyNodeTree
from bpy_extras.object_utils import object_data_add, AddObjectHelper

def surface(mesh, name):

    material = bpy.data.materials.new(name = "{}_moon_material".format(name))
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1800, y)

    noise_normal = nodes.new('ShaderNodeTexNoise')
    noise_normal.location = (x - 1600, y - 400)
    noise_normal.noise_dimensions = ('4D')
    noise_normal.inputs[2].default_value = 0.3
    noise_normal.inputs[3].default_value = 5.0
    noise_normal.inputs[4].default_value = 0.59
    noise_normal.inputs[5].default_value = 0.0
    noise_normal.name = ('noise_normal')

    noise_big = nodes.new('ShaderNodeTexNoise')
    noise_big.location = (x - 1600, y + 400)
    noise_big.noise_dimensions = ('4D')
    noise_big.inputs[2].default_value = 0.05
    noise_big.inputs[3].default_value = 0.0
    noise_big.inputs[4].default_value = 0.46
    noise_big.inputs[5].default_value = 0.0
    noise_big.name = ('noise_big')

    color_small = nodes.new('ShaderNodeValToRGB')
    color_small.location = (x - 1400, y)
    color_small.name = ('color_small')

    color_big = nodes.new('ShaderNodeValToRGB')
    color_big.location = (x - 1400, y + 400)
    color_big.color_ramp.interpolation = ('B_SPLINE')
    color_big.color_ramp.elements[0].position = 0.22
    color_big.color_ramp.elements[1].position = 0.36
    color_big.name = ('color_big')

    mix_rgb = nodes.new('ShaderNodeMixRGB')
    mix_rgb.location = (x - 1100, y)
    mix_rgb.blend_type = ('MULTIPLY')
    mix_rgb.inputs[0].default_value = 1.0

    color_color = nodes.new('ShaderNodeValToRGB')
    color_color.location = (x - 900, y)
    color_color.name = ('Object color')

    ramp = nodes.new('ShaderNodeRGBCurve')
    ramp.location = (x - 600, y)
    ramp.name = ('rgb_ramp')

    principled = nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (x - 300, y)
    principled.inputs[7].default_value = 0.0

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    bump = nodes.new('ShaderNodeBump')
    bump.location = (x - 900, y - 400)
    bump.inputs[0].default_value = 0.89
    bump.inputs[1].default_value = 0.6
    bump.name = ('bump_normals')

    # Links -------------
    nds.my_link(tex_coord, 3, noise_big, 0)
    nds.my_link(tex_coord, 3, noise_normal, 0)
    nds.my_link(noise_big, 0, color_big, 0)
    nds.my_link(noise_normal, 0, color_small, 0)
    nds.my_link(noise_normal, 0, bump, 2)
    nds.my_link(color_big, 0, mix_rgb, 2)
    nds.my_link(color_small, 0, mix_rgb, 1)
    nds.my_link(mix_rgb, 0, color_color, 0)
    nds.my_link(color_color, 0, ramp, 1)
    nds.my_link(ramp, 0, principled, 0)
    nds.my_link(bump, 0, principled, 22)
    nds.my_link(principled, 0, output, 0)
    


class MESH_OT_moon_object(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.moon_basic"
    bl_label = "Moon"
    bl_options = {'REGISTER', 'UNDO'}

    detail_level: bpy.props.IntProperty(
        name="Level of detail",
        description="Determines how many faces is in the mesh",
        default = 30,
        min = 0,
        soft_max = 100,
        max = 1000
    )

    radius: bpy.props.FloatProperty(
        name="Radius",
        description="Radius of planet",
        default = 10.0,
        min = 0.1,
        soft_max = 100
    )

    seed: bpy.props.FloatProperty(
        name="Seed",
        default = 1
    )

    count: bpy.props.IntProperty(
        name="Crater count",
        default = 1,
        min = 0
    )

    craters_size: bpy.props.IntProperty(
        name="Size of craters",
        default = 10,
        min = 0,
        soft_max = 100,
        max = 1000
    )

    def execute(self, context):
        cube = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Moon")

        cube.resize(self.detail_level)
        cube.project_to_sphere(self.radius)

        craters_objects = craters.create_random_craters(self.count, self.seed, cube.vertices, 10, self.radius, self.craters_size)
        moon_verts = []
        for vertex in cube.vertices:
            change = craters.calcHeight(vertex, craters_objects)
            if change != 1:
                moon_verts.append(cube.change_height(vertex, change, None))
            else:
                moon_verts.append(vertex)

        mesh.from_pydata(moon_verts, cube.edges, cube.faces)
        object_data_add(context, mesh, operator=self)
        obj = context.active_object
        mesh = obj.data
        
        for f in mesh.polygons:
            f.use_smooth = True

        bpy.ops.object.mode_set(mode = 'OBJECT')
        surface(mesh, obj.name)

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        obj['type'] = "moon"

        return {'FINISHED'}


def add_operator(self, context):
    self.layout.operator(MESH_OT_moon_object.bl_idname)


def register():
    bpy.utils.register_class(MESH_OT_moon_object)

def unregister():
    bpy.utils.unregister_class(MESH_OT_moon_object)