import bpy
from ..sphere import plain_object
from ..settings import settings
from bpy_extras.object_utils import object_data_add, AddObjectHelper

size = 10.0
# size of sphere = 2/5

def turn_off_reflection(obj):
    obj.visible_diffuse = False
    obj.visible_glossy = False
    obj.visible_transmission = False
    obj.visible_volume_scatter = False
    obj.visible_shadow = False

# Section for spinning effect (DM: <-1300-> || ^-750-v)
def spinning(x, y, nodes, links, scales, spin_relax, name):

    mix_out_1 = nodes.new('ShaderNodeMixRGB')
    mix_out_1.location = (x - 200, y + 750)
    mix_out_1.blend_type = ('OVERLAY')
    mix_out_1.inputs[0].default_value = 1.0

    mix_out_2 = nodes.new('ShaderNodeMixRGB')
    mix_out_2.location = (x - 200, y + 500)
    mix_out_2.blend_type = ('OVERLAY')
    mix_out_2.inputs[0].default_value = 1.0

    noise_s = nodes.new('ShaderNodeTexNoise')
    noise_s.location = (x - 400, y + 250)
    noise_s.inputs[2].default_value = scales[2]
    noise_s.name = ('{}_s'.format(name))

    noise_m = nodes.new('ShaderNodeTexNoise')
    noise_m.location = (x - 400, y + 500)
    noise_m.inputs[2].default_value = scales[1]
    noise_m.name = ('{}_m'.format(name))

    noise_l = nodes.new('ShaderNodeTexNoise')
    noise_l.location = (x - 400, y + 750)
    noise_l.inputs[2].default_value = scales[0]
    noise_l.name = ('{}_l'.format(name))

    mix_spin = nodes.new('ShaderNodeMixRGB')
    mix_spin.location = (x - 600, y + 500)
    mix_spin.inputs[0].default_value = spin_relax

    grad_tex = nodes.new('ShaderNodeTexGradient')
    grad_tex.location = (x - 800, y + 750)
    grad_tex.gradient_type = ('SPHERICAL')

    mapping = nodes.new('ShaderNodeMapping')
    mapping.location = (x - 1100, y + 500)
    mapping.inputs[3].default_value = (1.0, 1.0, 0.2)
    mapping.name = ('{}_mapping'.format(name))

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1300, y + 500)

    # Links
    links.new(tex_coord.outputs[3], mapping.inputs[0])
    links.new(mapping.outputs[0], grad_tex.inputs[0])
    links.new(mapping.outputs[0], mix_spin.inputs[2])
    links.new(grad_tex.outputs[0], mix_spin.inputs[1])
    links.new(mix_spin.outputs[0], noise_s.inputs[0])
    links.new(mix_spin.outputs[0], noise_m.inputs[0])
    links.new(mix_spin.outputs[0], noise_l.inputs[0])
    links.new(noise_s.outputs[0], mix_out_2.inputs[2])
    links.new(noise_m.outputs[0], mix_out_2.inputs[1])
    links.new(noise_l.outputs[0], mix_out_1.inputs[1])
    links.new(mix_out_2.outputs[0], mix_out_1.inputs[2])
    return mix_out_1.outputs[0]


# Material of center of black hole #####################################
def BH_sphere_mat(mesh):
    material = bpy.data.materials.new(name = "Black_hole_eye")
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    for node in nodes:
        nodes.remove(node)

    x = 0
    y = 0

    # Black sphere section
    # ---------------------------
    SPH_y = y

    SPH_refraction = nodes.new('ShaderNodeBsdfRefraction')
    SPH_refraction.location = (x - 200, SPH_y)
    SPH_refraction.inputs[0].default_value = (1,1,1,1)

    SPH_divide = nodes.new('ShaderNodeMath')
    SPH_divide.location = (x - 400, SPH_y)
    SPH_divide.operation = ('DIVIDE')
    SPH_divide.inputs[0].default_value = 1.0

    SPH_color = nodes.new('ShaderNodeValToRGB')
    SPH_color.location = (x - 700, SPH_y)
    SPH_color.color_ramp.elements[0].position = (0.8)
    SPH_color.name = ('refr_center')

    SPH_weight = nodes.new('ShaderNodeLayerWeight')
    SPH_weight.location = (x - 900, SPH_y)
    SPH_weight.inputs[0].default_value = 0.9

    # Links
    links.new(SPH_weight.outputs[1], SPH_color.inputs[0])
    links.new(SPH_color.outputs[0], SPH_divide.inputs[1])
    links.new(SPH_divide.outputs[0], SPH_refraction.inputs[2])
    SPH_out = SPH_refraction.outputs[0]


    # Color ring
    # ---------------------------
    RING_y = y + 300

    RING_subcolor = nodes.new('ShaderNodeValToRGB')
    RING_subcolor.location = (x - 300, RING_y)
    RING_subcolor.color_ramp.elements[0].position = (0.8)

    RING_color = nodes.new('ShaderNodeValToRGB')
    RING_color.location = (x - 600, RING_y)
    RING_color.color_ramp.elements[0].position = 0.74
    RING_color.color_ramp.elements[1].position = 0.76
    RING_color.color_ramp.elements.new(0.78)
    RING_color.color_ramp.elements[2].color = (0,0,0,1)
    RING_color.name = ('ring_shape')

    RING_weight = nodes.new('ShaderNodeLayerWeight')
    RING_weight.location = (x - 800, RING_y)
    RING_weight.inputs[0].default_value = 0.9

    RING_emision = nodes.new('ShaderNodeEmission')
    RING_emision.location = (x -200, RING_y - 600)
    RING_emision.inputs[1].default_value = 5.0
    

    RING_emision_color = nodes.new('ShaderNodeRGB')
    RING_emision_color.location = (x - 400, RING_y - 600)
    RING_emision_color.outputs[0].default_value = (1,1,1,1)
    RING_emision_color.name = ('ring_color')

    # Links
    links.new(RING_emision_color.outputs[0], RING_emision.inputs[0])
    links.new(RING_weight.outputs[1], RING_color.inputs[0])
    links.new(RING_color.outputs[0], RING_subcolor.inputs[0])
    RING_out = RING_subcolor.outputs[0]


    # Section linking
    # ---------------------------
    mix = nodes.new('ShaderNodeMixShader')
    mix.location = (x,y)

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x + 200, y)

    # Links
    links.new(RING_out, mix.inputs[0])
    links.new(SPH_out, mix.inputs[1])
    links.new(RING_emision.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], output.inputs[0])

# Material of disc of black hole #######################################
def BH_disc_mat(mesh):
    material = bpy.data.materials.new(name = "Black_hole_disc")
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    for node in nodes:
        nodes.remove(node)

    x = 0
    y = 0

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1000, y)

    mapping = nodes.new('ShaderNodeMapping')
    mapping.location = (x - 800, y)

    grad_tex = nodes.new('ShaderNodeTexGradient')
    grad_tex.location = ( x - 500, y)
    grad_tex.gradient_type = ('SPHERICAL')

    color_shape = nodes.new('ShaderNodeValToRGB')
    color_shape.location = (x - 300, y)
    color_shape.color_ramp.interpolation = ('B_SPLINE')
    color_shape.color_ramp.elements[0].position = 0.2
    color_shape.color_ramp.elements[1].position = 0.55
    color_shape.name = ('disc_shape')

    mix_1 = nodes.new('ShaderNodeMixRGB')
    mix_1.location = (x + 100, y + 200)
    mix_1.blend_type = ('MULTIPLY')
    mix_1.inputs[0].default_value = 1.0

    mix_2 = nodes.new('ShaderNodeMixRGB')
    mix_2.location = (x + 100, y - 200)
    mix_2.blend_type = ('MULTIPLY')
    mix_2.inputs[0].default_value = 1.0

    density_math = nodes.new('ShaderNodeMath')
    density_math.location = (x + 300, y + 200)
    density_math.operation = ('MULTIPLY')
    density_math.inputs[1].default_value = 200.0

    math_mult = nodes.new('ShaderNodeMath')
    math_mult.location = (x + 200, y)
    math_mult.operation = ('MULTIPLY')
    math_mult.inputs[1].default_value = 100.0

    color = nodes.new('ShaderNodeValToRGB')
    color.location = (x + 300, y - 200)
    color.name = ('Object color')

    principled = nodes.new('ShaderNodeVolumePrincipled')
    principled.location = (x + 600, y)

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x + 900, y)

    density_input = spinning(x, y + 200, nodes, links, (7.5, 20.0, 85.0), 0.25, "density")
    color_input = spinning(x, y - 1300, nodes, links, (4.0, 15.0, 60.0), 0.5, "color")

    # Links
    links.new(tex_coord.outputs[3], mapping.inputs[0])
    links.new(mapping.outputs[0], grad_tex.inputs[0])
    links.new(grad_tex.outputs[0], color_shape.inputs[0])
    links.new(color_shape.outputs[0], mix_1.inputs[2])
    links.new(color_shape.outputs[0], mix_2.inputs[1])
    links.new(color_shape.outputs[0], math_mult.inputs[0])
    links.new(density_input, mix_1.inputs[1])
    links.new(color_input, mix_2.inputs[2])
    links.new(mix_1.outputs[0], density_math.inputs[0])
    links.new(mix_2.outputs[0], color.inputs[0])
    links.new(density_math.outputs[0], principled.inputs[2])
    links.new(math_mult.outputs[0], principled.inputs[6])
    links.new(color.outputs[0], principled.inputs[0])
    links.new(color.outputs[0], principled.inputs[7])
    links.new(principled.outputs[0], output.inputs[1])






    
    

def assign_material(material_func, obj):
    bpy.ops.object.mode_set(mode = 'OBJECT')
    material_func(obj.data)
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type="FACE")
    bpy.ops.mesh.select_all(action = 'SELECT')
    obj.active_material_index = 0
    bpy.ops.object.material_slot_assign()
    bpy.ops.object.mode_set(mode = 'OBJECT')

# Black Hole operator ########################################################
class MESH_OT_black_hole(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.black_hole"
    bl_label = "Add Black hole"
    bl_option = {'REGISTER',  'UNDO'}


    def execute(self, context):
        settings.set_cycles()

        # Sphere of Black Hole
        sphere = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Black_hole")

        sphere.resize(30)
        sphere.project_to_sphere((size*2)/5)

        mesh.from_pydata(sphere.vertices, sphere.edges, sphere.faces)
        object_data_add(context, mesh, operator=self)
        mesh = context.object.data

        for f in mesh.polygons:
            f.use_smooth = True

        eye = context.active_object
        assign_material(BH_sphere_mat, eye)

        bpy.ops.mesh.primitive_cube_add()
        disc = context.active_object
        assign_material(BH_disc_mat, disc)
        disc.scale = (size, size,size/20)

        black_hole_parts = [
            eye,
            disc
        ]

        eye['parts'] = black_hole_parts
        eye['type'] = "black_hole"
        eye["scale_vector"] = eye.scale.copy()
        eye["scale_factor"] = 1
        disc['parts'] = black_hole_parts
        disc['type'] = "black_hole"

        turn_off_reflection(eye)
        return {'FINISHED'}

def add_operator(self, context):
    self.layout.operator(MESH_OT_black_hole.bl_idname)

def register():
    bpy.utils.register_class(MESH_OT_black_hole)

def unregister():
    bpy.utils.unregister_class(MESH_OT_black_hole)