import bpy

def vector_3_to_4(color):
    return (color[0], color[1], color[2], 1.0)

def star_level(x, y, color, scale, nodes, links, in_link, strength, space_color):

    if scale > 250.0:
        scale = 250.0

    mapping = nodes.new('ShaderNodeMapping')
    mapping.location = (x - 1400, y)

    voronoi = nodes.new('ShaderNodeTexVoronoi')
    voronoi.location  =  (x  - 1200, y)
    voronoi.inputs[2].default_value = scale
    voronoi.name = ('voronoi_{}'.format(strength))

    color_ramp_stars = nodes.new('ShaderNodeValToRGB')
    color_ramp_stars.location = (x -  1000, y)
    color_ramp_stars.color_ramp.elements[0].position = (0.0)
    color_ramp_stars.color_ramp.elements[0].color = (2,2,2,1)
    color_ramp_stars.color_ramp.elements[1].position = (0.05)
    color_ramp_stars.color_ramp.elements[1].color = space_color

    color_ramp_color = nodes.new('ShaderNodeValToRGB')
    color_ramp_color.location = (x - 700, y)
    colors = color_ramp_color.color_ramp.elements
    colors.new(0.05)
    colors.new(0.2)
    colors[1].color = color
    colors[2].color = color
    for i in range(0,3):
        colors[2].color[i] = (colors[2].color[i] * 4) + 0.3 
    
    color_ramp_color.name = ('color_{}'.format(strength))

    background = nodes.new('ShaderNodeBackground')
    background.location = (x -  400, y)

    bloom = 3 - strength
    if bloom < 1:
        bloom = 1
    background.inputs[1].default_value = bloom

    # Links
    links.new(in_link, mapping.inputs[0])
    links.new(mapping.outputs[0], voronoi.inputs[0])
    links.new(voronoi.outputs[0], color_ramp_stars.inputs[0])
    links.new(color_ramp_stars.outputs[0],  color_ramp_color.inputs[0])
    links.new(color_ramp_color.outputs[0], background.inputs[0])

    return background.outputs[0]

def color_variations(x, y, nodes, links, stars_in):

    # Factor nodes ------------

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1400, y + 600)

    fac_seed = nodes.new('ShaderNodeValue')
    fac_seed.location = (x - 1400, y + 300)
    fac_seed.name = ('fac_seed')

    fac_mapping = nodes.new('ShaderNodeMapping')
    fac_mapping.location = (x - 1100, y + 600)
    fac_mapping.name = ('fac_mapping')

    fac_noise = nodes.new('ShaderNodeTexNoise')
    fac_noise.location = (x - 700, y + 600)
    fac_noise.noise_dimensions = ('4D')
    fac_noise.name = ('fac_noise')

    fac_math = nodes.new('ShaderNodeMath')
    fac_math.location = (x - 500, y + 600)
    fac_math.operation = ('POWER')
    fac_math.inputs[1].default_value = 5.6
    fac_math.name = ('fac_math')

    # Links
    links.new(tex_coord.outputs[0], fac_mapping.inputs[0])
    links.new(fac_seed.outputs[0], fac_mapping.inputs[1])
    links.new(fac_mapping.outputs[0], fac_noise.inputs[0])
    links.new(fac_noise.outputs[0], fac_math.inputs[0])
    factor = fac_math.outputs[0]

    # Color nodes -------------

    col_seed = nodes.new('ShaderNodeValue')
    col_seed.location = (x - 1400, y + 200)
    col_seed.name = ('Color seed')

    col_mapping = nodes.new('ShaderNodeMapping')
    col_mapping.location = (x - 1100, y + 300)

    col_noise = nodes.new('ShaderNodeTexNoise')
    col_noise.location = (x - 900, y + 300)
    col_noise.name = ('col_noise')

    col_color = nodes.new('ShaderNodeValToRGB')
    col_color.location = (x - 600, y + 300)
    col_color.name = ('Clouds color')

    # Links
    links.new(tex_coord.outputs[0], col_mapping.inputs[0])
    links.new(col_seed.outputs[0], col_mapping.inputs[1])
    links.new(col_mapping.outputs[0], col_noise.inputs[0])
    links.new(col_noise.outputs[0], col_color.inputs[0])
    color = col_color.outputs[0]

    # Mix ---------------------
    mix = nodes.new('ShaderNodeMixShader')
    mix.location = (x - 200, y + 600)

    # Links
    links.new(stars_in, mix.inputs[1])
    links.new(factor, mix.inputs[0])
    links.new(color, mix.inputs[2])

    return mix.outputs[0]

class OBJECT_OT_set_background(bpy.types.Operator):
    bl_idname = "mesh.set_background"
    bl_label = "Space background"
    bl_options = {'REGISTER', 'UNDO'}

    stars_color_0: bpy.props.FloatVectorProperty(  
        name="Biggest stars color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        description="color picker"
    )

    stars_color_1: bpy.props.FloatVectorProperty(  
        name="Big stars color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        description="color picker"
    )

    stars_color_2: bpy.props.FloatVectorProperty(  
        name="Small stars color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        description="color picker"
    )

    stars_color_3: bpy.props.FloatVectorProperty(  
        name="Smallest stars color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        description="color picker"
    )

    space_color: bpy.props.FloatVectorProperty(  
        name="Space color",
        subtype='COLOR',
        default=(0.0, 0.0, 0.0),
        min=0.0, max=1.0,
        description="color picker"
    )

    def execute(self, context):

        wrld = context.scene.world

        nt = bpy.data.worlds[wrld.name].node_tree
        nodes = nt.nodes
        links = nt.links

        star_levels = 6
        for node in nodes:
            nodes.remove(node)

        world_node = nodes.new('ShaderNodeOutputWorld')
        world_node.location = (400, 400)
        world_out = world_node.inputs[0]

        colors = [
            vector_3_to_4(self.stars_color_0),
            vector_3_to_4(self.stars_color_1),
            vector_3_to_4(self.stars_color_2),
            vector_3_to_4(self.stars_color_3),
            vector_3_to_4(self.stars_color_3),
            vector_3_to_4(self.stars_color_3)
            ]


        tex_coord = nodes.new('ShaderNodeTexCoord')
        tex_coord.location = ((-2000), 400)

        prev_level_out = None
        prev_level_in = None
        stars_out = None
        for i in range(0, star_levels):
            level_out = star_level(0, i * 400,  colors[i], ((i + 1) * 50),\
                nodes, links, tex_coord.outputs[3], i, vector_3_to_4(self.space_color))

            

            if i > 0:
                # In loop
                shader_mix = nodes.new('ShaderNodeMixShader')
                shader_mix.location = (0, (i*400) - 200)

                links.new(level_out, shader_mix.inputs[1])
                links.new(prev_level_in, shader_mix.inputs[2])
                links.new(shader_mix.outputs[0], prev_level_out)

                prev_level_out = shader_mix.inputs[1]
                prev_level_in = level_out
                if i == 1:
                    stars_out = shader_mix.outputs[0]
                
            else:
                links.new(level_out, world_out)
                prev_level_out = world_out
                prev_level_in = level_out
                stars_out = level_out

        # Color of "clouds"
        shader = color_variations(0, -1000, nodes, links, stars_out)
        
        links.new(shader, world_out)

        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_set_background)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_set_background)