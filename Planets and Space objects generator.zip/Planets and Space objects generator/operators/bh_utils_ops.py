# Black hole  reloccate, select both
import bpy

class MESH_OT_bh_disc_location(bpy.types.Operator):
    bl_idname = "mesh.bh_disc_location"
    bl_label = "Relocate disc"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object

        try:
            eye = obj['parts'][0]
            disc = obj['parts'][1]
            disc.location = eye.location
        except:
            pass

        return {'FINISHED'}


class MESH_OT_bh_selection(bpy.types.Operator):
    bl_idname = "mesh.bh_selection"
    bl_label = "Select all parts of BH"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        obj = context.active_object
        try:
            eye = obj['parts'][0]
            disc = obj['parts'][1]
            eye.select_set(True)
            disc.select_set(True)
        except:
            pass


        return {'FINISHED'}



def register():
    bpy.utils.register_class(MESH_OT_bh_disc_location)
    bpy.utils.register_class(MESH_OT_bh_selection)


def unregister():
    bpy.utils.unregister_class(MESH_OT_bh_disc_location)
    bpy.utils.unregister_class(MESH_OT_bh_selection)