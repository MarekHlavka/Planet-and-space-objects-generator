from email.policy import default
import bpy

def reset_compositor(nodes, links):
    for node in nodes:
        nodes.remove(node)

    composite = nodes.new('CompositorNodeComposite')
    composite.location = (300, 400)
    
    layers = nodes.new('CompositorNodeRLayers')
    layers.location = (0, 400)

    links.new(layers.outputs[0], composite.inputs[0])

class OBJECT_OT_set_compositing(bpy.types.Operator):
    bl_idname = "mesh.set_compositing"
    bl_label = "Aftereffects"
    bl_options = {'REGISTER', 'UNDO'}

    reset_type: bpy.props.BoolProperty(
        name="Switch",
        default = True
    )

    def execute(self, context):

        prev_ui = context.area.ui_type

        bpy.context.area.ui_type = 'CompositorNodeTree'
        bpy.data.scenes["Scene"].use_nodes = True
        nt = bpy.context.scene.node_tree
        context.area.ui_type = prev_ui

        nodes = nt.nodes
        links = nt.links

        reset_compositor(nodes, links)

        if self.reset_type == True:
            render = nodes.get('Render Layers')
            render.location.x = (-500)
            composite = nodes.get('Composite')

            glare = nodes.new('CompositorNodeGlare')
            glare.location = (0, 400)
            glare.glare_type = ('FOG_GLOW')
            glare.quality = ('HIGH')
            glare.threshold = 0.015
            glare.size = 8

            denoise = nodes.new('CompositorNodeDenoise')
            denoise.location = (-200, 400)

        
            # Links
            links.new(render.outputs[0], denoise.inputs[0])
            links.new(denoise.outputs[0], glare.inputs[0])
            links.new(glare.outputs[0], composite.inputs[0])

        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_set_compositing)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_set_compositing)