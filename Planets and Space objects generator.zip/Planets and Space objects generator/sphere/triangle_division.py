from mathutils import Vector
import time

face_time = 0

class Division():

    #TODO - change list for Vector
    # Creating number of midpoints between two points
    # a - Starting point
    # b - Ending point
    # return list - [point a, midpoint 1, ..., midpoint x, point b]
    def create_midpoints(a, b, number_of_midpoints) -> list:
        number_of_edges = number_of_midpoints + 1
        dist_x = (b.x - a.x) / number_of_edges
        dist_y = (b.y - a.y) / number_of_edges
        dist_z = (b.z - a.z) / number_of_edges

        points = [a]
        for i in range(0, number_of_midpoints):
            new_midpoint_x = (a.x + (dist_x * (i+1)))    # x
            new_midpoint_y = (a.y + (dist_y * (i+1)))    # y
            new_midpoint_z = (a.z + (dist_z * (i+1)))    # z
            points.append(Vector((new_midpoint_x, new_midpoint_y, new_midpoint_z)))

        points.append(b)
        return points


    # Create many triangles inside one given
    #       .                      .
    #      / \                    / \
    #     /   \      --->        /___\
    #    /     \                /\   /\
    #   /_______\              /__\_/__\
    #
    # a, b, c - points of triangle
    # divide_levels - number of midpoins for each side
    # return list of lists - each list for line of vertices in triangle
    def divide_one_triangle(a, b, c, divide_levels) -> list:
        first_level = Division.create_midpoints(a, b, divide_levels)
        a_side = Division.create_midpoints(a, c, divide_levels)
        b_side = Division.create_midpoints(b, c, divide_levels)

        # all vetricies of newly divided triangles -> have to create faces from this
        all_verts_triangle = []
        all_verts_triangle.append(first_level)

        for i in range(1, divide_levels + 1):
            current_level = []
            current_level = Division.create_midpoints(a_side[i], b_side[i], divide_levels - i)

            # APPEND - RETURNS LIST OF LISTS
            all_verts_triangle.append(current_level)
        
        all_verts_triangle.append([c])
        return all_verts_triangle


    
    # Create divided faces from newly calculated vertices
    def calculate_faces(list_line_indexes):
        new_faces = []
        # Loop by line except of last line - only one vertex - cannot be created any faces
        # and next list can be accesed
        for line in range(0, len(list_line_indexes) - 1):
            # Loop by indexes except of last index - its faces will be already processed
            # Last index can be accesed by previous one without error
            for index in range(0, len(list_line_indexes[line]) - 1):
                new_faces.append([
                    list_line_indexes[line][index],
                    list_line_indexes[line][index + 1],
                    list_line_indexes[line + 1][index]])

                if(index != 0):
                    new_faces.append([
                        list_line_indexes[line][index],
                        list_line_indexes[line + 1][index],
                        list_line_indexes[line + 1][index - 1]])

        return new_faces

    # TODO - upraveno na nevyhledevani v indexech - vic pameti, ale vyssi rychlost
    # Find vertex in list of vertices or add new vertex to this list
    # vertices - original list of vertices
    # vertex - vertex to be found/added
    # return list [ new list of vericies, index of vertex]
    def get_index_of_vertex(vertices, vertex, is_border) -> list:

        # check if vertex is already in mesh
        if not is_border:
                # its new veretex
            index = len(vertices)
            vertices.append(vertex)
        else:
            # border vertex - have to check
            for i in range(0, len(vertices)):
                if vertices[i] == vertex:
                   return(vertices, i)
            index = len(vertices)
            vertices.append(vertex)
        return(vertices, index)

    # Check every new vertex if is in final list of vetrices, or add it to that list
    # Create list of indexes of vertices of newly divided triangle
    # From those indexes create faces level by level 
    # original verts - list of verices before processing current triangle
    # new_triangle_verts - list of vertices to be added
    # Return list [ new list of vertices, new faces to be added]
    def triangle_verts_to_faces(original_verts, new_triangle_verts):
        list_of_indexes = []
        new_vertices = []
        my_time = 0
        # Find index for each vertex in each list
        for j, line_list in enumerate(new_triangle_verts):
            
            line_indexes = []
            
            # TOO LONG - MULTIPROCESSING
            start = time.time()
            for i, vertex in enumerate(line_list):
                is_border = False
                if i == 0 or i == len(line_list) - 1 or j == 0:
                    is_border = True
                retlist = Division.get_index_of_vertex(original_verts, vertex, is_border)

                new_vertices = retlist[0]
                line_indexes.append(retlist[1])
            list_of_indexes.append(line_indexes)
            my_time += (time.time() - start)
        print(my_time)
        new_faces = Division.calculate_faces(list_of_indexes)
        return[new_vertices, new_faces] 

        

    # return list [vertices, faces]
    def divide_triangles(original_verts, original_faces, divide_levels) -> list:
        new_verts_list = []
        new_verts_list.extend(original_verts)
        new_face_list = []

        divide_time = 0
        face_time = 0

        for face in original_faces:
            # Get vertices of current face
            face_verts = [original_verts[face[0]], original_verts[face[1]], original_verts[face[2]]]
            # Divide triangle
            start = time.time()
            new_vertices = Division.divide_one_triangle(face_verts[0], face_verts[1], face_verts[2], divide_levels)
            end = time.time()
            divide_time += end - start
            
            # Triangle verts to faces
            start = time.time()
            retlist = Division.triangle_verts_to_faces(new_verts_list, new_vertices)
            end = time.time()
            face_time += end - start
            
            new_verts_list = retlist[0]
            new_face_list.extend(retlist[1])

        print("Dividing triangle = ", divide_time)
        print("Calc faces = ", face_time)
        return [new_verts_list, new_face_list]
    