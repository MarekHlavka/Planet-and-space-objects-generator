import bpy
from bpy_extras.object_utils import object_data_add, AddObjectHelper
from . import plain_object
from ..settings.my_node_tree import MyNodeTree

def clouds(mesh):
    material = bpy.data.materials.new(name = "Sun_surface")
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0


    # Clouds shape ---------------------------------------------------------------

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1400, y)

    mapping = nodes.new('ShaderNodeMapping')
    mapping.location = (x - 1200, y)

    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (x - 900, y)
    noise.inputs[2].default_value = 2.4     # Scale
    noise.inputs[3].default_value = 10.4    # Detail
    noise.inputs[4].default_value = 0.7     # Roughness
    noise.inputs[5].default_value = 2.3     # Distortion

    color_shape = nodes.new('ShaderNodeValToRGB')
    color_shape.location = (x - 700, y)
    color_shape.color_ramp.interpolation = ('CONSTANT')
    color_shape.color_ramp.elements[1].position = (0.48)

    # Links
    nds.my_link(tex_coord, 0, mapping, 0)
    nds.my_link(mapping, 0, noise, 0)
    nds.my_link(noise, 1, color_shape, 0)

    # Clouds color ---------------------------------------------------------------

    noise_color = nodes.new('ShaderNodeTexNoise')
    noise_color.location = (x - 1400, y - 500)
    noise_color.inputs[2].default_value = 3.1   # Scale
    noise_color.inputs[3].default_value = 2.0   # Detail
    noise_color.inputs[4].default_value = 0.5   # Roughness
    noise_color.inputs[5].default_value = 26.3  # Distortion

    color_color = nodes.new('ShaderNodeValToRGB')
    color_color.location = (x - 1200, y - 500)
    color_color.name = ('Object color')

    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    bsdf.location = (x - 900, y - 500)
    bsdf.inputs[20].default_value = 0.0

    # Links
    nds.my_link(noise_color, 0, color_color, 0)
    nds.my_link(color_color, 0, bsdf, 0)
    nds.my_link(color_color, 0, bsdf, 3)

    # Clouds output --------------------------------------------------------------

    mix = nodes.new('ShaderNodeMixShader')
    mix.location = (x - 200, y)

    transparent = nodes.new('ShaderNodeBsdfTransparent')
    transparent.location = (x - 400, y - 300)
    transparent.inputs[0].default_value = (1,1,1,1)

    output = nodes.new('ShaderNodeOutputMaterial')

    # Links
    nds.my_link(color_shape, 0, mix, 0)
    nds.my_link(bsdf, 0, mix, 1)
    nds.my_link(transparent, 0, mix, 2)
    nds.my_link(mix, 0, output, 0)



class MESH_OT_sphere_clouds(bpy.types.Operator, AddObjectHelper):
    bl_idname = "mesh.sphere_clouds"
    bl_label = "Add clouds to sphere"
    bl_options = {'REGISTER', 'UNDO'}

    radius: bpy.props.FloatProperty(
        name="Radius",
        description="Distance between sphere and clouds",
        default = 1.0,
        min = 0.1,
        soft_max = 100
    )

    def execute(self, context):

        if context.active_object is None:
            self.report({'ERROR'}, "Object have to be selected!")
            return {'FINISHED'}
        location = context.active_object.location
        try:
            sphere_radius = context.active_object['radius']
        except:
            sphere_radius = 10.0

        cube = plain_object.plain_3D_object(1)
        mesh = bpy.data.meshes.new(name="Clouds")

        cube.resize(30)
        cube.project_to_sphere(self.radius/50 + sphere_radius)

        mesh.from_pydata(cube.vertices, cube.edges, cube.faces)
        object_data_add(context, mesh, operator=self)
        mesh = context.object.data
        
        for f in mesh.polygons:
            f.use_smooth = True
        
        obj = context.active_object
        mesh = obj.data

        bpy.ops.object.mode_set(mode = 'OBJECT')
        clouds(mesh)

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        return {'FINISHED'}


def add_operator(self, context):
    self.layout.operator(MESH_OT_sphere_clouds.bl_idname)


def register():
    bpy.utils.register_class(MESH_OT_sphere_clouds)

def unregister():
    bpy.utils.unregister_class(MESH_OT_sphere_clouds)