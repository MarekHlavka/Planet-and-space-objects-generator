from mathutils import Vector
from mathutils import noise
import math
import time
import random
from . import triangle_division
from ..general import planet_noise
from ..general import water_border

# Class for creating simple cube and convering it to sphere\
# Golden ratio = 1.618
class plain_3D_object():

    golden_ration = 1.618

    # Distance from S(0,0,0)
    def distance_to_center(self, vertex):
        dist_x = vertex.x * vertex.x
        dist_y = vertex.y * vertex.y
        dist_z = vertex.z * vertex.z

        return math.sqrt(dist_x + dist_y + dist_z)

    def init_vertices(self, size):
        vertices = []

        vertices.append(Vector((size*self.golden_ration, 0, size)))
        vertices.append(Vector((size*self.golden_ration, 0, -size)))
        vertices.append(Vector((-size*self.golden_ration, 0, -size)))
        vertices.append(Vector((-size*self.golden_ration, 0, size)))

        vertices.append(Vector((0, size, size*self.golden_ration)))
        vertices.append(Vector((0, -size, size*self.golden_ration)))
        vertices.append(Vector((0, -size, -size*self.golden_ration)))
        vertices.append(Vector((0, size, -size*self.golden_ration)))

        vertices.append(Vector((size, size*self.golden_ration, 0)))
        vertices.append(Vector((-size, size*self.golden_ration, 0)))
        vertices.append(Vector((-size, -size*self.golden_ration, 0)))
        vertices.append(Vector((size, -size*self.golden_ration, 0)))

        return vertices

    def init_faces(self):
        faces = [
            [0,4,5],
            [0,8,4],
            [0,1,8],
            [0,11,1],
            [0,5,11],
            [1,7,8],
            [1,6,7],
            [1,11,6],
            [10,11,5],
            [10,6,11],
            [9,8,7],
            [9,4,8],
            [3,5,4],
            [3,10,5],
            [3,2,10],
            [3,9,2],
            [3,4,9],
            [2,9,7],
            [2,6,10],
            [2,7,6]
            
        ]
        return faces

    def resize(self, level):
        start = time.time()
        # No division
        if level > 0:
            # No need for recalculating current vertices
            if self.levels != level:
                new_vals = triangle_division.Division.divide_triangles(self.vertices, self.faces, level)
                self.vertices = new_vals[0]
                self.faces = new_vals[1]
                print(len(self.vertices))
            self.levels = level
        end = time.time()
        print("Resize time = ", end - start)

        

    def change_height(self, vertex, resize_value, ocean_level):
        
        new_vertex = Vector((
            vertex.x * resize_value,
            vertex.y * resize_value,
            vertex.z * resize_value
            ))
        return new_vertex

    def project_to_sphere(self, radius):
        new_vertices = []
        for vertex in self.vertices:
            resize_value = (radius / self.distance_to_center(vertex))
            new_vertices.append(self.change_height(vertex, resize_value, resize_value))

        self.vertices = new_vertices

    def simple_noise(self, ocean_level, seed, continents, water_amount, heigh_factor):
        new_verices = []
        biomes_points = planet_noise.Planet_noise.calc_biomes_points(4, water_amount)

        random.seed(seed)
        offset_val = random.random()

        for vertex in self.vertices:
            noise_val = planet_noise.Planet_noise.complex_noise(vertex, biomes_points,
             Vector((offset_val, offset_val, offset_val)), continents, water_amount)
            new_verices.append(self.change_height(vertex, (1 + noise_val * heigh_factor / 20), ocean_level))

        self.vertices = new_verices
        print("--------------------------------")
        print(planet_noise.Planet_noise.minimum)
        print(planet_noise.Planet_noise.maximum)

    def __init__(self, size) -> None:
        self.size = size
        self.edges = []
        self.vertices = self.init_vertices(self.size)
        self.faces = self.init_faces()
        self.levels = None

