
import bpy
import bmesh
from ..settings.my_node_tree import MyNodeTree
from bpy_extras.object_utils import object_data_add, AddObjectHelper

def ring_material(mesh):
    material = bpy.data.materials.new(name = "Sun_surface")
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    # Ring shape and color -------------------------------------------------------

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 2400, y)

    vec_length = nodes.new('ShaderNodeVectorMath')
    vec_length.location = (x - 2200, y)
    vec_length.operation = ('LENGTH')

    math_sine = nodes.new('ShaderNodeMath')
    math_sine.location = (x - 2000, y)
    math_sine.operation = ('SINE')

    map_range = nodes.new('ShaderNodeMapRange')
    map_range.location = (x - 1800, y)

    rgb_curves = nodes.new('ShaderNodeRGBCurve')
    rgb_curves.location = (x - 1600, y)
    rgbC = rgb_curves.mapping.curves[3]
    rgbC.points.new(.2,.1)
    rgbC.points.new(.44,.44)
    rgbC.points.new(.6,.9)
    rgb_curves.inputs[1].default_value = (0.95, 0.08, 0.1, 1)

    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (x - 1300, y)
    noise.inputs[2].default_value = 150.0   # Scale
    noise.inputs[3].default_value = 0.0     # Detail
    noise.inputs[4].default_value = 0.0     # Roughness
    noise.inputs[5].default_value = 3.3     # Distortion

    color = nodes.new('ShaderNodeValToRGB')
    color.location = (x - 1100, y)
    color.name = ('Object color')

    math_power = nodes.new('ShaderNodeMath')
    math_power.location = (x - 800, y)
    math_power.operation = ('POWER')
    math_power.inputs[1].default_value = 0.3

    math_mult = nodes.new('ShaderNodeMath')
    math_mult.location = (x - 500, y)
    math_mult.operation = ('MULTIPLY')
    math_mult.inputs[1].default_value = -1.0

    # Links 
    nds.my_link(tex_coord, 3, vec_length, 0)
    nds.my_link(math_sine, 0, map_range, 0)
    nds.my_link(vec_length, 1, math_sine, 0)
    nds.my_link(map_range, 0, rgb_curves, 0)
    nds.my_link(rgb_curves, 0, noise, 0)
    nds.my_link(noise, 0, color, 0)
    nds.my_link(color, 0, math_power, 0)
    nds.my_link(math_power, 0, math_mult, 0)

    # Trasparency ----------------------------------------------------------------

    principled = nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (x - 800, y - 300)
    principled.inputs[20].default_value = 0.0

    mix_downside = nodes.new('ShaderNodeMixShader')
    mix_downside.location = (x - 500, y - 300)
    mix_downside.inputs[0].default_value = 0.002

    transparent = nodes.new('ShaderNodeBsdfTransparent')
    transparent.location = (x - 500, y - 500)
    transparent.inputs[0].default_value = (1,1,1,1)

    # Links 
    nds.my_link(color, 0, principled, 0)
    nds.my_link(color, 0, mix_downside, 2)
    nds.my_link(principled, 0, mix_downside, 1)

    # Output ---------------------------------------------------------------------

    mix = nodes.new('ShaderNodeMixShader')
    mix.location = (x - 200, y)

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    # Links
    nds.my_link(math_mult, 0, mix, 0)
    nds.my_link(mix_downside, 0, mix, 1)
    nds.my_link(transparent, 0, mix, 2)
    nds.my_link(mix, 0, output, 0)


class MESH_OT_sphere_ring(AddObjectHelper, bpy.types.Operator):
    bl_idname = "mesh.sphere_ring"
    bl_label = "Sphere rings"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        if context.active_object is None:
            self.report({'ERROR'}, "Object have to be selected!")
            return {'FINISHED'}
        location = context.active_object.location
        radius = context.active_object['radius']

        me = bpy.data.meshes.new("Ring")

        bm = bmesh.new()

        bmesh.ops.create_circle(bm, radius=(radius + 3), segments=50)
        bmesh.ops.create_circle(bm, radius=(radius + 8), segments=50)

        ret = bmesh.ops.bridge_loops(bm, edges=bm.edges)
        bm.to_mesh(me)

        object_data_add(context, me, operator=self)

        obj = context.active_object
        obj.location = location
        mesh = obj.data

        bpy.ops.object.mode_set(mode = 'OBJECT')
        ring_material(mesh)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        return {'FINISHED'}




def register():
    bpy.utils.register_class(MESH_OT_sphere_ring)


def unregister():
    bpy.utils.unregister_class(MESH_OT_sphere_ring)