from typing import Mapping
import bpy

class VIEW3D_PT_background_stars(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_background_stars"
    bl_parent_id = "VIEW3D_PT_background_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Background settings"
    bl_label = "Background stars"

    def draw(self, context):
        layout = self.layout
        
        wrld = context.scene.world
        nt = bpy.data.worlds[wrld.name].node_tree

        texts = [
            "Large",
            "Medium",
            "Smaller"
        ]

        for i in range(0, 3):
            box = layout.box()
            box.label(text="{} stars".format(texts[i]))

            voronoi = nt.nodes['voronoi_{}'.format(i)]
            if voronoi is not None:
                box.prop(voronoi.inputs[2], 'default_value', text="Size of {} stars".format(texts[i].lower()))

            color = nt.nodes['color_{}'.format(i)]
            if color is not None:
                sub_box = box.box()
                sub_box.label(text="Color of {} stars".format(texts[i].lower()))
                sub_box.template_color_ramp(color, 'color_ramp', expand=True)





class VIEW3D_PT_background_clouds(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_background_clouds"
    bl_parent_id = "VIEW3D_PT_background_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Background settings"
    bl_label = "Background clouds"

    def draw(self, context):
        layout = self.layout

        wrld = context.scene.world
        nt = bpy.data.worlds[wrld.name].node_tree

        # Shape
        mapping = nt.nodes['fac_seed']
        noise = nt.nodes['fac_noise']
        math = nt.nodes['fac_math']

        if mapping is not None or noise is not None or math is not None:
            box = layout.box()
            box.label(text="Shape")

            if mapping is not None:
                box.prop(mapping.outputs[0], 'default_value', text="Seed")

            if noise is not None:
                col = box.column()
                col.label(text="Clouds texture")
                for  i in noise.inputs[1:]:
                    col.prop(i, 'default_value', text=i.name)

            if math is not None:
                box.prop(math.inputs[1], 'default_value', text="Threshold")

        # Color

        seed = nt.nodes['Color seed']
        noise = nt.nodes['col_noise']
        color = nt.nodes['Clouds color']

        if seed is not None or noise is not None or color is not None:
            box = layout.box()
            box.label(text="Color")

            col = box.column()
            if seed is not None:
                col.prop(seed.outputs[0], 'default_value', text="Seed")

            if noise is not None:
                col.prop(noise.inputs[2], 'default_value', text="Color scale")

            if color is not None:
                sub_box = box.box()
                sub_box.label(text="Clouds color")
                sub_box.template_color_ramp(color, 'color_ramp', expand=True)




class VIEW3D_PT_background_panel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_background_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Background settings"
    bl_label = "Space background"

    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.set_background", text="Set Background")

def register():
    bpy.utils.register_class(VIEW3D_PT_background_panel)
    bpy.utils.register_class(VIEW3D_PT_background_stars)
    bpy.utils.register_class(VIEW3D_PT_background_clouds)
    

def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_background_panel)
    bpy.utils.unregister_class(VIEW3D_PT_background_stars)
    bpy.utils.unregister_class(VIEW3D_PT_background_clouds)