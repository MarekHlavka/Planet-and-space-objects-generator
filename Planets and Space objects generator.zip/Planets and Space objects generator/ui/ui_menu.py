
import bpy
import sys
from ..general import plain_sphere
from ..other_obj import sun_object
from ..other_obj import moon_object
from ..other_obj import asteroid

custom_icons = None

class OBJECT_MT_default_submenu(bpy.types.Menu):
    bl_idname = "OBJECT_MT_default_submenu"
    bl_label = "Add basic generated space objects"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        pass
        




class OBJECT_MT_planet_submenu(bpy.types.Menu):
    bl_idname = "OBJECT_MT_planet_submenu"
    bl_label = "Add Planets and Space objects"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        pass
        



class OBJECT_MT_space_menu(bpy.types.Menu):
    bl_idname = "OBJECT_MT_space_menu"
    bl_label = "Planets and space objects generator"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        layout.operator(plain_sphere.MESH_OT_plain_sphere.bl_idname, text="Planet")
        layout.operator(sun_object.MESH_OT_sun_basic.bl_idname)
        layout.operator(moon_object.MESH_OT_moon_object.bl_idname)
        layout.operator("mesh.galaxy", text="Galaxy")
        layout.operator("mesh.black_hole", text="Black Hole")
        layout.operator("mesh.nebula", text="Nebula")
        layout.operator(asteroid.MESH_OT_asteroid_object.bl_idname, text="Asteroid")
        layout.operator("mesh.asteroid_field", text="Asteroid field")
        layout.operator("mesh.gas_giant", text="Gas giant")



def add_submenu(self, context):
    self.layout.menu(OBJECT_MT_space_menu.bl_idname, text="PaSOG", icon='WORLD')


def register():
    bpy.utils.register_class(OBJECT_MT_planet_submenu)
    bpy.utils.register_class(OBJECT_MT_default_submenu)
    bpy.utils.register_class(OBJECT_MT_space_menu)
    bpy.types.VIEW3D_MT_add.append(add_submenu)


def unregister():
    bpy.utils.unregister_class(OBJECT_MT_planet_submenu)
    bpy.utils.unregister_class(OBJECT_MT_default_submenu)
    bpy.utils.unregister_class(OBJECT_MT_space_menu)
    bpy.types.VIEW3D_MT_add.remove(add_submenu)
