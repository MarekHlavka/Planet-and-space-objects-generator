import bpy

class land_types(bpy.types.PropertyGroup):
    land_enum : bpy.props.EnumProperty(
        name = "Landtype",
        description = "Choose landtype",
        items = [
            ("WATER", "Water", ""),
            ("LAND", "Landtype 1", ""),
            ("MOUNT", "Landtype 2", ""),
            ("ICE", "Landtype 3", "")
        ]
    )

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def land_color(layout, name):
    noise = get_node('{}_noise'.format(name))
    color = get_node('{}_color'.format(name))
    thres = get_node('{}_thresh'.format(name))

    if noise is not None or color is not None or thres is not None:
        box = layout.box()

        if thres is not None:
            layout.box().prop(thres.inputs[1], 'default_value', text="Threshold")

        if noise is not None:
            col = box.column()
            col.label(text="Texture")
            for i in noise.inputs[1:]:
                col.prop(i, 'default_value', text=i.name)

        if color is not None:
            sub_box = box.box()
            sub_box.label(text="Landtype color")
            sub_box.template_color_ramp(color, 'color_ramp', expand=True)


def border_noise(layout):
    
    noise = get_node('noise_border')

    if noise is not None:
        box = layout.box()
        box.label(text="Noise for landtype borders")

        col = box.column()
        for i in noise.inputs[1:]:
            col.prop(i, 'default_value', text=i.name)



def planet_panel(layout, context):

    if bpy.context.active_object.active_material is not None:
        

        box = layout.box()
        box.label(text="PLANET")

        landtypes = context.scene.landtypes
        box.prop(landtypes, "land_enum")

        border_noise(box)
        if landtypes.land_enum == "ICE":
            land_color(box, 'ice')
        elif landtypes.land_enum == "MOUNT":
            land_color(box, 'mount')
        elif landtypes.land_enum == "LAND":
            land_color(box, 'land')
        else:
            if bpy.context.active_object['water'] > 0.0:
                land_color(box, 'water')





def register():
    bpy.utils.register_class(land_types)
    bpy.types.Scene.landtypes = bpy.props.PointerProperty(type=land_types)
    

def unregister():
    bpy.utils.unregister_class(land_types)
    del bpy.types.Scene.landtypes