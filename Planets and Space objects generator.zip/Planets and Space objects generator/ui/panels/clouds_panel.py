
import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def clouds_panel(layout, context):

    if bpy.context.active_object.active_material is not None:
        obj = context.active_object

        box = layout.box()
        box.label(text="CLOUDS")
        box.operator("mesh.sphere_ring_center", text="Reset location")

        shape_noise = get_node('shape_noise')
        shape_color = get_node('color_shape')

        if shape_noise is not None and shape_color is not None:
            sub_box = box.box()
            column = sub_box.column()
            for i in shape_noise.inputs[1:]:
                column.prop(i, 'default_value', text=i.name)

            sub_box.label(text="Noise threshold")
            sub_box.template_color_ramp(shape_color, "color_ramp", expand=True)

        color_noise = get_node('color_noise')
        color = get_node('Object color')

        if color_noise is not None and color is not None:
            sub_box = box.box()
            column = sub_box.column()
            for i in color_noise.inputs[1:]:
                column.prop(i, 'default_value', text=i.name)

            sub_box.label(text="Color")
            sub_box.template_color_ramp(color, "color_ramp", expand=True)

def register():
    pass

def unregister():
    pass