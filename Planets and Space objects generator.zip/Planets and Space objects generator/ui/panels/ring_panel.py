import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def ring_panel(layout, context):

    if bpy.context.active_object.active_material is not None:
        obj = context.active_object

        box = layout.box()
        box.label(text="RING")

        sub_box = box.box()
        sub_box.prop(obj, 'location')
        sub_box.prop(obj, 'rotation_euler')
        sub_box.prop(obj, 'scale')

        box.operator("mesh.sphere_ring_center", text="Reset location")

        
        noise = get_node('noise')
        if noise is not None:
            sub_box = box.box()
            sub_box.prop(noise.inputs[2], 'default_value', text="Scale texture")
            sub_box.prop(noise.inputs[3], 'default_value', text="Detail texture")

        
        rgb_curve = get_node('rgb_curves')
        if rgb_curve is not None:
            sub_box = box.box()
            sub_box.label(text="Texture")
            sub_box.template_curve_mapping(rgb_curve, 'mapping', type='COLOR')

        color = get_node('Object color')
        if color is not None:
            sub_box = box.box()
            sub_box.label(text="Color")
            sub_box.template_color_ramp(color, "color_ramp", expand=True)

        alpha_curve = get_node('curve_alpha')
        if alpha_curve is not None:
            sub_box = box.box()
            sub_box.label(text = "Transparency")
            sub_box.template_curve_mapping(alpha_curve, 'mapping')

        

class MESH_OT_ring_center(bpy.types.Operator):
    bl_idname = "mesh.sphere_ring_center"
    bl_label = "Sphere rings center"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.active_object.location = context.active_object['planet'].location
        return {'FINISHED'}

def register():
    bpy.utils.register_class(MESH_OT_ring_center)

def unregister():
    bpy.utils.unregister_class(MESH_OT_ring_center)