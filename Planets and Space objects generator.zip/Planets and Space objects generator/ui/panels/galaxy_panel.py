import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def galaxy_panel(layout, context):
    
    if bpy.context.active_object.active_material is not None:
        

        box = layout.box()
        box.label(text="GALAXY")

        # box ---------------------------------
        sub_box = box.box()

        galaxy_shape = get_node('galaxy_shape')
        if galaxy_shape is not None:
            sub_box.prop(galaxy_shape.inputs[2], 'default_value', text="Galaxy shape")

        galaxy_rotation = get_node('galaxy_rotation')
        if galaxy_rotation is not None:
            sub_box.prop(galaxy_rotation.inputs[1], 'default_value', text="Rotation of galaxy")

        galaxy_rotation_falloff = get_node('galaxy_rotation_falloff')
        if galaxy_rotation_falloff is not None:
            sub_box.prop(galaxy_rotation_falloff.inputs[1], 'default_value', text="Falloff of rotation")

        center_size = get_node('center_size')
        if center_size is not None:
            sub_box.prop(center_size.outputs[0], 'default_value', text="Size of center")

        spin_noise = get_node('spin_noise')
        if spin_noise is not None:
            sub_box.prop(spin_noise.inputs[0], 'default_value', text="Noise in spin")
        
        # box ---------------------------------
        sub_box = box.box()

        small_size = get_node('small_stars_size')
        if small_size is not None:
            sub_box.prop(small_size.inputs[2], 'default_value', text="Size of small stars")
        
        small_nof = get_node('small_stars_nof')
        if small_nof is not None:
            sub_box.label(text="Count of small stars")
            sub_box.template_color_ramp(small_nof, "color_ramp", expand=True)

        # box ---------------------------------
        sub_box = box.box()

        big_size = get_node('big_stars_size')
        if big_size is not None:
            sub_box.prop(big_size.inputs[2], 'default_value', text="Size of big stars")
        
        big_nof = get_node('big_stars_nof')
        if big_nof is not None:
            sub_box.label(text="Count of big stars")
            sub_box.template_color_ramp(big_nof, "color_ramp", expand=True)

        # box ---------------------------------
        color = get_node('Object color')
        if color is not None:
            sub_box = box.box()
            sub_box.label(text="Galaxy color")
            sub_box.template_color_ramp(color, "color_ramp", expand=True)




def register():
    pass

def unregister():
    pass