import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def nebula_panel(layout, context):

    if bpy.context.active_object.active_material is not None:
        box = layout.box()
        box.label(text="NEBULA")

        sub_box = box.box() # --------------------------------
        sub_box.label(text="Main shape")

        seed = get_node('main_mapping')
        if seed is not None:
            sub_box.prop(seed.inputs[1], 'default_value', text="Seed")

        main_noise = get_node('main_noise')
        if main_noise is not None:
            for i in main_noise.inputs[2:-1]:
                sub_box.prop(i, 'default_value', text=i.name)

        main_color = get_node('main_color')
        if main_color is not None:
            sub_box.label(text="Threshold for shape")
            sub_box.template_color_ramp(main_color, "color_ramp", expand=True)
        

        sub_box = box.box() # --------------------------------
        sub_box.label(text="Edges")

        edges_noise = get_node('edges_noise')
        if edges_noise is not None:
            for i in edges_noise.inputs[2:-1]:
                sub_box.prop(i, 'default_value', text=i.name)

        edges_color = get_node('edges_color')
        if edges_color is not None:
            sub_box.label(text="Threshold for edges")
            sub_box.template_color_ramp(edges_color, "color_ramp", expand=True)


        color = get_node('Object color')
        if color is not None:
            sub_box = box.box()
            sub_box.label(text="Nebula color")
            sub_box.template_color_ramp(color, "color_ramp", expand=True)


def register():
    pass

def unregister():
    pass