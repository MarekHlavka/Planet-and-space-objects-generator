import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def asteroid_panel(layout, context):

    if bpy.context.active_object.active_material is not None:
        box = layout.box()
        box.label(text="ASTEROID")

        noise = get_node('noise_color')
        bump = get_node('bump_normals')
        color = get_node('Object color')

        if noise is not None:
            box1 = box.box()
            box1.label(text="Texture")
            sub_box = box1.column()
            for i in noise.inputs[1:-1]:
                sub_box.prop(i, 'default_value', text=i.name)

        if bump is not None:
            box1 = box.box()
            box1.label(text="Normals")
            sub_box = box1.column()
            for i in bump.inputs[:-4]:
                sub_box.prop(i, 'default_value', text=i.name)

        if color is not None:
            box1 = box.box()
            box1.label(text="Color")
            box1.template_color_ramp(color, "color_ramp", expand=True)


        pass

def register():
    pass

def unregister():
    pass