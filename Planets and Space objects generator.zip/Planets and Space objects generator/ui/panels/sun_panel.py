import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def sun_panel(layout, context):
    if bpy.context.active_object.active_material is not None:
        
        box = layout.box()
        box.label(text="SUN")

        texture_1 = get_node('tex_1')
        color_1 = get_node('color_1')

        if texture_1 is not None or color_1 is not None:
            sub_box = box.box()
            sub_box.label(text="Large")

            if texture_1 is not None:
                col = sub_box.column()
                col.label(text="Large texture")
                for i in texture_1.inputs[1:-2]:
                    col.prop(i, 'default_value', text=i.name)

            if color_1 is not None:
                sub_sub_box = sub_box.box()
                sub_sub_box.label(text="Large color")
                sub_sub_box.template_color_ramp(color_1, 'color_ramp', expand=True)

        texture_2 = get_node('tex_2')
        color_2 = get_node('color_2')

        if texture_2 is not None or color_2 is not None:
            sub_box = box.box()
            sub_box.label(text="Medium")

            if texture_2 is not None:
                col = sub_box.column()
                col.label(text="Medium texture")
                for i in texture_2.inputs[1:-2]:
                    col.prop(i, 'default_value', text=i.name)

            if color_2 is not None:
                sub_sub_box = sub_box.box()
                sub_sub_box.label(text="Medium color")
                sub_sub_box.template_color_ramp(color_2, 'color_ramp', expand=True)

        texture_3 = get_node('tex_3')
        color_3 = get_node('color_3')

        if texture_3 is not None or color_3 is not None:
            sub_box = box.box()
            sub_box.label(text="Small")

            if texture_3 is not None:
                col = sub_box.column()
                col.label(text="Small texture")
                for i in texture_3.inputs[1:-2]:
                    col.prop(i, 'default_value', text=i.name)

            if color_3 is not None:
                sub_sub_box = sub_box.box()
                sub_sub_box.label(text="Small color")
                sub_sub_box.template_color_ramp(color_3, 'color_ramp', expand=True)



def register():
    pass

def unregister():
    pass