import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def moon_panel(layout, context):

    if bpy.context.active_object.active_material is not None:

        box_b = layout.box()
        box_b.label(text="MOON")

        box = box_b.box()
        box.label(text="Big surace")

        noise_big = get_node('noise_big')
        color_big = get_node('color_big')

        if noise_big is not None:
            box.label(text="Big texture")
            box.prop(noise_big.inputs[1], 'default_value', text="Offset")
            box.prop(noise_big.inputs[2], 'default_value', text="Scale")

        if color_big is not None:
            box.label(text="Big texture threholds")
            box.template_color_ramp(color_big, "color_ramp", expand=True)
            

        box = box_b.box()
        box.label(text="Detailed surface")

        noise_normal = get_node('noise_normal')
        color_small = get_node('color_small')
        bump = get_node('bump_normals')

        if noise_normal is not None:
            box.label(text="Small texture")
            box.prop(noise_normal.inputs[1], 'default_value', text="Offset")
            box.prop(noise_normal.inputs[2], 'default_value', text="Scale")

        if color_small is not None:
            box.label(text="Small texture threholds")
            box.template_color_ramp(color_small, "color_ramp", expand=True)

        if bump is not None:
            box.label(text="Normals")
            box.prop(bump.inputs[1], 'default_value', text="Strength")
            box.prop(bump.inputs[2], 'default_value', text="Distance")


        box = box_b.box()
        box.label(text="Color")

        color = get_node('Object color')
        ramp = get_node('rgb_ramp')

        if color is not None:
            box1 = box.box()
            box1.template_color_ramp(color, "color_ramp", expand=True)

        if ramp is not None:
            box1 = box.box()
            box1.template_curve_mapping(ramp, 'mapping', type='COLOR')


def register():
    pass

def unregister():
    pass