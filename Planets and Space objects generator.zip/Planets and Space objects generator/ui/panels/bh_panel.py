
import bpy
from mathutils import Vector

class bh_panel_props(bpy.types.PropertyGroup):
    bh_enum : bpy.props.EnumProperty(
        name = "Black hole part",
        description = "Choose part of black hole",
        items = [
            ("OB_EYE", "Center of BH", ""),
            ("OB_DISC", "Disc of BH", "")
        ]
    )




def get_node(material, name):
    try:
        node = bpy.data.materials[material].node_tree.nodes[name]
    except:
        node = None

    return node





def bh_center_panel(obj, layout, mat):
    
    box = layout.box()
    box.label(text="Center shape")
    box.prop(obj, 'scale', text="Size of center")

    refr_center = get_node(mat, 'refr_center')
    if refr_center is not None:
        box = layout.box()
        box.label(text="Center refraction")
        box.template_color_ramp(refr_center, "color_ramp", expand=True)

    
    ring_shape = get_node(mat, 'ring_shape')
    if ring_shape is not None:
        box = layout.box()
        box.label(text="Size of color stripe")
        box.template_color_ramp(ring_shape, "color_ramp", expand=True)

    ring_color = get_node(mat, 'ring_color')
    if ring_color is not None:
        box = layout.box()
        box.label(text="Color of color stripe")
        box.template_color_picker(ring_color.outputs[0], 'default_value', value_slider=True)



def bh_disc_panel(obj, layout, mat):
    
    shape = get_node(mat, 'disc_shape')
    if shape is not None:
        box = layout.box()
        box.label(text="Shape of disc")
        box.template_color_ramp(shape, "color_ramp", expand=True)

    rot_diff = get_node(mat, 'density_mapping')
    if rot_diff is not None:
        box = layout.box()
        box.label(text="Rotation (e.g., for animation)")
        box.prop(rot_diff.inputs[2], 'default_value', text = "")

    rot_color = get_node(mat, 'color_mapping')
    if rot_color is not None:
        box = layout.box()
        box.label(text="Rotation of color (e.g., for animation)")
        box.prop(rot_color.inputs[2], 'default_value', text = "")
    # ring texture

    density_s = get_node(mat, 'density_s')
    density_m = get_node(mat, 'density_m')
    density_l = get_node(mat, 'density_l')
    if not(density_s is None and density_m is None and density_l is None):
        box = layout.box()
        box.label(text="Texture of disc")
        col = box.row()
        col.prop(density_s.inputs[2], 'default_value', text="")
        col.prop(density_m.inputs[2], 'default_value', text="")
        col.prop(density_l.inputs[2], 'default_value', text="")

    color = get_node(mat, 'Object color')
    if color is not None:
        box = layout.box()
        box.label(text="Overall color")
        box.template_color_ramp(color, "color_ramp", expand=True)


def bh_panel(parts, layout, context):
    scene = context.scene
    bh_props = scene.bh_props

    box = layout.box()
    box.label(text="BLACK HOLE")

    row = box.row()
    row.operator("mesh.bh_disc_location", text="Location disc reset")
    row.operator("mesh.bh_selection", text="Select Both")

    box = layout.box()
    box.prop(bh_props, "bh_enum")
    
    
    if bh_props.bh_enum == "OB_EYE":
        bh_center_panel(parts[0], box, parts[0].active_material.name)
    else:
        bh_disc_panel(parts[1], box, parts[1].active_material.name)






def scale_obj(self, context):
    self.scale = self.scale_factor * Vector(self.scale_vector)
    print("etf")

def register():
    bpy.utils.register_class(bh_panel_props)
    bpy.types.Scene.bh_props = bpy.props.PointerProperty(type= bh_panel_props)
    bpy.types.Object.scale_factor = bpy.props.FloatProperty(
        name = "Scale Factor",
        default=1,
        update=scale_obj
    )

def unregister():
    bpy.utils.unregister_class(bh_panel_props)
    del bpy.types.Scene.bh_props
    del bpy.types.Object.scale_factor