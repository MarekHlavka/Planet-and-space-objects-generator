import bpy

def get_node(name):
    mat_name = bpy.context.active_object.active_material.name
    try:
        node = bpy.data.materials[mat_name].node_tree.nodes[name]
    except:
        node = None

    return node

def gas_panel(layout, context):

    if bpy.context.active_object.active_material is not None:
        
        box = layout.box()
        box.label(text="GAS GIANT")

        # Ringss
        texture_noise = get_node('texture_noise')
        eye_range = get_node('eye_range')
        rgb_curve = get_node('rgb_curve')

        if texture_noise is not None or eye_range is not None or rgb_curve is not None:
            sub_box = box.box()
            sub_box.label(text="Rings texture")

            if texture_noise is not None:
                col = sub_box.column()
                col.label(text="Rings borders")
                for i in texture_noise.inputs[2:]:
                    col.prop(i, 'default_value', text=i.name)

            if eye_range is not None:
                sub_box.prop(eye_range.inputs[4], 'default_value', text="Rings scale")

            if rgb_curve is not None:
                sub_sub_box = sub_box.box()
                sub_sub_box.label(text="Rings texture")
                sub_sub_box.template_curve_mapping(rgb_curve, 'mapping', type="COLOR")


        # Storms
        eye_voronoi = get_node('eye_voronoi')
        eye_noise = get_node('eye_noise')
        eye_color = get_node('eye_color')

        if eye_voronoi is not None or eye_noise is not None or eye_color is not None:
            sub_box = box.box()
            sub_box.label(text="Storms")

            if eye_voronoi is not None:
                col = sub_box.column()
                col.prop(eye_voronoi.inputs[1], 'default_value', text="Storms location")
                col.prop(eye_voronoi.inputs[2], 'default_value', text="Storms number")

            if eye_noise is not None:
                col = sub_box.column()
                col.label(text="Noise for storms edges")
                for i in eye_noise.inputs[2:]:
                    col.prop(i, 'default_value', text=i.name)

            if eye_color is not None:
                sub_sub_box = sub_box.box()
                sub_sub_box.label(text="Sharpnes os storm edges")
                sub_sub_box.template_color_ramp(eye_color, 'color_ramp', expand=True)


        # Color
        color = get_node('Object color')
        if color is not None:
            sub_box = box.box()
            sub_box.label(text="Color")
            sub_box.template_color_ramp(color, "color_ramp", expand=True)


    pass

def register():
    pass

def unregister():
    pass