
import bpy
from .panels.galaxy_panel import galaxy_panel
from .panels.nebula_panel import nebula_panel
from .panels.bh_panel import bh_panel
from .panels.moon_panel import moon_panel
from .panels.asteroid_panel import asteroid_panel
from .panels.ring_panel import ring_panel
from .panels.clouds_panel import clouds_panel
from .panels.gas_panel import gas_panel
from .panels.planet_panel import planet_panel
from .panels.sun_panel import sun_panel

colorable = [
    "Test"
]
obj_types = [
    "galaxy",
    "nebula",
    "black_hole",
    "planet",
    "moon",
    "asteroid",
    "ring",
    "clouds",
    "gas_giant",
    "sun"
]

def get_object_name(obj):
    if obj is None:
        return obj
    return obj.name.split(".")[0]
    
class VIEW3D_PT_planet_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Space objects"
    bl_label = "Space object"



    def draw(self, context):
        layout = self.layout
        box1 = layout.box()
        op1 = box1.operator("mesh.set_compositing", text="Set Blur")
        op1.reset_type = True
        op2 = box1.operator("mesh.set_compositing", text="Reset Blur")
        op2.reset_type = False

        scene_name = bpy.context.scene.name
        col = box1.column()
        col.prop(bpy.data.scenes[scene_name].render, "engine")

        if bpy.data.scenes[scene_name].render.engine == 'CYCLES':
            col.prop(bpy.data.scenes[scene_name].cycles, "feature_set")
            col.prop(bpy.data.scenes[scene_name].cycles, "device")


        if context.active_object is not None:
            try:
                type = context.active_object["type"]
                if type in obj_types:
                    if type == "galaxy":
                        galaxy_panel(layout, context)
                    elif type == "nebula":
                        nebula_panel(layout, context)
                    elif type == "black_hole":
                        bh_panel(context.active_object['parts'], layout, context)
                    elif type == "planet":
                        box = layout.box()
                        box.operator("mesh.plain_sphere_color", text="Color")
                        box.operator("mesh.smooth_edges", text="Smooth Edges")
                        box.operator("mesh.sphere_ring", text="Planet ring")
                        box.operator("mesh.sphere_clouds", text="Add clouds")

                        if context.active_object["subtype"] == "plain":
                            planet_panel(layout, context)
                        elif context.active_object["subtype"] == "gas_giant":
                            gas_panel(layout, context)
                            pass

                    elif type == "moon":
                        moon_panel(layout, context)
                    elif type == "asteroid":
                        asteroid_panel(layout, context)
                    elif type == "ring":
                        ring_panel(layout, context)
                    elif type == "clouds":
                        clouds_panel(layout, context)
                    elif type == "sun":
                        box = layout.box()
                        box.operator("mesh.sphere_ring", text="Planet ring")
                        sun_panel(layout, context)




            except:
                pass
                    


def register():
    bpy.utils.register_class(VIEW3D_PT_planet_panel)
    

def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_planet_panel)