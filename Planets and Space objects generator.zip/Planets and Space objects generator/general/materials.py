from typing import DefaultDict
import bpy

class Materials():

    def water(context, mesh):
        
        material = bpy.data.materials.new(name = "Water")
        material.use_nodes = True

        mesh.materials.append(material)
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        principled_node = nodes.get('Principled BSDF')
        rgb_node = nodes.new('ShaderNodeRGB')
        rgb_node.location = (-250, 0)
        rgb_node.outputs[0].default_value = (0.5, 1, 1, 1)

        links.new(rgb_node.outputs[0], principled_node.inputs[0])

    def land(context, mesh):
        material = bpy.data.materials.new(name = "Land")
        material.use_nodes = True

        mesh.materials.append(material)
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        principled_node = nodes.get('Principled BSDF')
        rgb_node = nodes.new('ShaderNodeRGB')
        rgb_node.location = (-250, 0)
        rgb_node.outputs[0].default_value = (0.1, 0.5, 0.0, 1)

        links.new(rgb_node.outputs[0], principled_node.inputs[0])

    def mountain(context, mesh):
        material = bpy.data.materials.new(name = "Mountain")
        material.use_nodes = True

        mesh.materials.append(material)
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        principled_node = nodes.get('Principled BSDF')
        rgb_node = nodes.new('ShaderNodeRGB')
        rgb_node.location = (-250, 0)
        rgb_node.outputs[0].default_value = (0.5, 0.4, 0.2, 1)

        links.new(rgb_node.outputs[0], principled_node.inputs[0])

    def sand(context, mesh):
        material = bpy.data.materials.new(name = "Sand")
        material.use_nodes = True

        mesh.materials.append(material)
        nodes = material.node_tree.nodes
        links = material.node_tree.links

        principled_node = nodes.get('Principled BSDF')
        rgb_node = nodes.new('ShaderNodeRGB')
        rgb_node.location = (-250, 0)
        rgb_node.outputs[0].default_value = (1, 0.95, 0.5, 1)

        links.new(rgb_node.outputs[0], principled_node.inputs[0]) 