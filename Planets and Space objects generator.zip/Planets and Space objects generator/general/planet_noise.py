from mathutils import Vector
from mathutils import noise

class Biomes():

    def plains(vertex, offset):
        value = (noise.hetero_terrain(vertex + offset, 1.0, 2.0, 8, 0))
        retval = ((abs(value)**0.05) - 0.6)
        return retval

    def mountains(vertex, offset):
        value = noise.hetero_terrain(vertex + offset * 1.5, 1.0, 2.0, 8, 0)
        retval = value * 1.5 + 1.5
        return retval

    def hills(vertex, offset):
        value = noise.hetero_terrain(vertex/2 + offset, 1.0, 2.0, 8, 0)
        retval = value + 1.5
        return retval

    def water(vertex):
        return 0
        

class Planet_noise():

    water_count = 0
    all_count = 0
    maximum = 0
    minimum = 0

    def calc_biomes_points(biomes_count, water_amount):
        division = 1 / ( biomes_count - 1)
        biomes_points = []

        for i in range(0, biomes_count):
            biomes_points.append((division * i) + water_amount)

        return biomes_points

    def area_type(vertex, biomes_points, offset, continents, water_amount):
        modifiers = []
        value = (noise.noise((vertex/8 * continents) + offset) + 1)/2
        
        Planet_noise.all_count = Planet_noise.all_count + 1

        if value < Planet_noise.minimum:
            Planet_noise.minimum = value

        if value > Planet_noise.maximum:
            Planet_noise.maximum = value

        if value < water_amount:

            Planet_noise.water_count = Planet_noise.water_count + 1

            for point in biomes_points:
                modifiers.append(0.0)
            modifiers[0] = (1 - abs(value - biomes_points[0]))
            

        else:
            for point in biomes_points:
                weight = abs(1 - abs(value - point))**3.5
                modifiers.append(weight)
            modifiers[0] = 0.0

        return modifiers

    def complex_noise(vertex, biomes_points, offset, continents, water_amount):
        m = Biomes.mountains(vertex, offset)
        p = Biomes.plains(vertex, offset)
        w = Biomes.water(vertex)
        h = Biomes.hills(vertex, offset)

        co_modifiers = Planet_noise.area_type(vertex, biomes_points, offset, continents, water_amount)

        retval = (w * co_modifiers[0] + p * co_modifiers[1] + h * co_modifiers[2] + m * co_modifiers[3])
        return retval