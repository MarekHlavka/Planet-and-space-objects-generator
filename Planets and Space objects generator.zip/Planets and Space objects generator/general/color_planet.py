import bpy
from ..settings.my_node_tree import MyNodeTree

def get_object_name(obj):
    if obj is None:
        return obj
    return obj.name.split(".")[0]

offset = 0.05
colorable = [
    "Test"
]

# Nodes for calculating distance from origin of object
# Output - distance
def vec_length(nds, x , y):
    nodes = nds.get_nodes()

    tex_coord =  nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x, y)

    dot_product = nodes.new('ShaderNodeVectorMath')
    dot_product.location = (x + 200, y)
    dot_product.operation = ('DOT_PRODUCT')

    sqrt_math = nodes.new('ShaderNodeMath')
    sqrt_math.location = (x + 400, y)
    sqrt_math.operation = ('SQRT')

    # Links
    nds.my_link(tex_coord, 3, dot_product, 0)
    nds.my_link(tex_coord, 3, dot_product, 1)
    nds.my_link(dot_product, 1, sqrt_math, 0)

    return sqrt_math.outputs[0]


# Nodes to determine strength of specific color  for  each point
# Output - Fac
def threshold(nds, x, y, radius, thres_diff, dst, noise_val, hard_edges, name):
    nodes = nds.get_nodes()

    thres = nodes.new('ShaderNodeMath')
    thres.location = (x, y)
    thres.inputs[1].default_value = thres_diff
    thres.name = ('{}_thresh'.format(name))

    sub_noise = nodes.new('ShaderNodeMath')
    sub_noise.location = (x + 200, y)
    sub_noise.operation = ('SUBTRACT')
    if noise_val is None:
        sub_noise.inputs[1].default_value = 0.5

    sub_dst = nodes.new('ShaderNodeMath')
    sub_dst.location = (x + 400, y)
    sub_dst.operation = ('SUBTRACT')

    power = nodes.new('ShaderNodeMath')
    power.location = (x + 600,  y)
    if hard_edges:
        power.operation = ('ROUND')
    else:
        power.operation = ('POWER')
        power.inputs[1].default_value = 4.0

    # Links

    nds.my_link(radius, 0, thres, 0)
    nds.my_link(dst, -1, sub_dst, 0)
    if noise_val is not None:
        nds.my_link(noise_val, -1, sub_noise, 1)
    nds.my_link(thres, 0, sub_noise, 0)
    nds.my_link(sub_noise, 0, sub_dst, 1)
    nds.my_link(sub_dst, 0, power, 0)

    return power.outputs[0]


# Nodes for changing border betwen two color section
# Output - noise value
def noise_border(nds, x, y):
    nodes = nds.get_nodes()

    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (x ,y)
    noise.noise_dimensions = ('4D')
    noise.inputs[1].default_value = 11.7    # Scale
    noise.inputs[2].default_value = 14.4    # Detail
    noise.inputs[3].default_value = 1.0     # Roughness
    noise.inputs[4].default_value = 2.1     # Distortion
    noise.name = ('noise_border')

    divide = nodes.new('ShaderNodeMath')
    divide.location = (x + 200, y)
    divide.operation = ('DIVIDE')
    divide.inputs[1].default_value = 4.0

    subtract = nodes.new('ShaderNodeMath')
    subtract.location = (x + 400, y)
    subtract.operation = ('SUBTRACT')
    subtract.inputs[1].default_value = 0.125

    add_math = nodes.new('ShaderNodeMath')
    add_math.location = (x + 600, y)
    add_math.operation = ('ADD')
    add_math.inputs[1].default_value = 0.5

    # Links
    nds.my_link(noise, 0, divide, 0)
    nds.my_link(divide, 0, subtract, 0)
    nds.my_link(subtract, 0, add_math, 0)

    return add_math.outputs[0]


def noise_color(nds, x , y, color_1, color_2, name):
    nodes = nds.get_nodes()

    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (x, y)
    noise.noise_dimensions = ('4D')
    noise.name = ('{}_noise'.format(name))

    color = nodes.new('ShaderNodeValToRGB')
    color.location = (x + 200, y)
    color.color_ramp.elements[0].color = color_1
    color.color_ramp.elements[1].color = color_2
    color.name = ('{}_color'.format(name))

    # Links
    nds.my_link(noise, 0, color, 0)
    return color.outputs[0]

def mix(nds, x, y, fac, in_1, in_2):
    nodes = nds.get_nodes()

    mix_shader = nodes.new('ShaderNodeMixRGB')
    mix_shader.location = (x, y)

    nds.my_link(fac, -1, mix_shader, 0)
    nds.my_link(in_1, -1, mix_shader, 1)
    nds.my_link(in_2, -1, mix_shader, 2)

    return mix_shader.outputs[0]


def color_mesh(mesh, name, radius):
    material = bpy.data.materials.new(name = "Surface_{}".format(name))
    material.use_nodes = True
    mesh.materials.append(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    radius_val = nodes.new('ShaderNodeValue')
    radius_val.location = (x - 3000, y + 500)
    radius_val.outputs[0].default_value = radius

    vec_dst = vec_length(nds, x - 3000, y)

    border_noise = noise_border(nds, x - 3000, y - 500)

    water_border = threshold(nds, x - 2000, y + 500, radius_val, 0, vec_dst, None, True, 'water')
    mountains_border = threshold(nds, x - 2000, y, radius_val, -radius/100, vec_dst, border_noise, False, 'mount')
    icebergs_border = threshold(nds, x - 2000, y -  500, radius_val, radius/20, vec_dst, border_noise, True, 'ice')


    land_color = noise_color(nds, x - 1400, y + 300, (0,0.5,0,1), (0,0.5,0,1), 'land')
    mountains_color = noise_color(nds, x - 1400, y - 200, (0.01, 0.001, 0, 1), (0.01, 0.001, 0, 1), 'mount')
    icebergs_color = noise_color(nds, x - 1400, y - 800, (1,1,1,1), (1,1,1,1), 'ice')
    water_color = noise_color(nds, x - 1700, y + 900, (0,0,1,1), (0.5, 0.5, 1, 1), 'water')

    mix_1 = mix(nds, x - 800, y, mountains_border, land_color, mountains_color)
    mix_2 = mix(nds, x - 600, y - 300,icebergs_border, mix_1, icebergs_color)
    mix_3 = mix(nds, x - 400, y, water_border, water_color, mix_2)

    principled = nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (x -200, y)

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x + 100, y)

    # Links

    nds.my_link(mix_3, -1, principled, 0)
    nds.my_link(principled, 0, output, 0)





class OBJECT_OT_plain_sphere_color(bpy.types.Operator):
    bl_idname = "mesh.plain_sphere_color"
    bl_label = "Plain Sphere Color"
    bl_options = {'REGISTER', 'UNDO'}
    

    def execute(self, context):
        obj = context.active_object
        mesh = obj.data

        # reslovning active object name
        obj_name = get_object_name(obj)
        
        # chack if object can be colored+
        if obj_name in colorable:

            radius = obj['radius']

            bpy.ops.object.mode_set(mode = 'OBJECT')
            color_mesh(mesh, obj.name, radius)

            bpy.ops.object.mode_set(mode = 'EDIT')
            bpy.ops.mesh.select_mode(type="FACE")
            bpy.ops.mesh.select_all(action = 'SELECT')
            obj.active_material_index = 0
            bpy.ops.object.material_slot_assign()
            bpy.ops.object.mode_set(mode = 'OBJECT') 

            

        return{'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_plain_sphere_color)
    

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_plain_sphere_color)