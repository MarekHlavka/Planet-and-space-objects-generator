
import bpy
import bmesh
from ..settings.my_node_tree import MyNodeTree
from bpy_extras.object_utils import object_data_add, AddObjectHelper

def turn_off_reflection(obj):
    obj.visible_diffuse = False
    obj.visible_glossy = False
    obj.visible_transmission = False
    obj.visible_volume_scatter = False
    obj.visible_shadow = True

def mat_blend_type(mat):
    mat.blend_method = 'BLEND'

def ring_material(mesh):
    material = bpy.data.materials.new(name = "Ring_surface")
    material.use_nodes = True
    mesh.materials.append(material)
    mat_blend_type(material)

    nodes = material.node_tree.nodes
    links = material.node_tree.links

    nds = MyNodeTree(nodes, links)
    nds.clear_nodes()

    x = 0
    y = 0

    # Ring shape and color -------------------------------------------------------

    tex_coord = nodes.new('ShaderNodeTexCoord')
    tex_coord.location = (x - 1900, y)

    vec_length = nodes.new('ShaderNodeVectorMath')
    vec_length.location = (x - 1700, y)
    vec_length.operation = ('LENGTH')

    math_sine = nodes.new('ShaderNodeMath')
    math_sine.location = (x - 1500, y)
    math_sine.operation = ('SINE')

    map_range = nodes.new('ShaderNodeMapRange')
    map_range.location = (x - 1300, y)
    map_range.inputs[1].default_value = -1.0

    rgb_curves = nodes.new('ShaderNodeRGBCurve')
    rgb_curves.location = (x - 1100, y)
    rgbC = rgb_curves.mapping.curves[3]
    rgbC.points.new(.2,.1)
    rgbC.points.new(.44,.44)
    rgbC.points.new(.6,.9)
    rgb_curves.inputs[1].default_value = (0.95, 0.08, 0.1, 1)
    rgb_curves.name = ('rgb_curves')

    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (x - 800, y)
    noise.inputs[2].default_value = 150.0   # Scale
    noise.inputs[3].default_value = 0.0     # Detail
    noise.inputs[4].default_value = 0.0     # Roughness
    noise.inputs[5].default_value = 3.3     # Distortion
    noise.name = ('noise')

    color = nodes.new('ShaderNodeValToRGB')
    color.location = (x - 600, y)
    color.name = ('Object color')


    # Links 
    nds.my_link(tex_coord, 3, vec_length, 0)
    nds.my_link(math_sine, 0, map_range, 0)
    nds.my_link(vec_length, 1, math_sine, 0)
    nds.my_link(map_range, 0, rgb_curves, 0)
    nds.my_link(rgb_curves, 0, noise, 0)
    nds.my_link(noise, 0, color, 0)

    # Trasparency ----------------------------------------------------------------

    curve = nodes.new('ShaderNodeFloatCurve')
    curve.location = (x - 600, y - 400)
    curve.name = ('curve_alpha')

    principled = nodes.new('ShaderNodeBsdfPrincipled')
    principled.location = (x - 300, y)
    principled.inputs[20].default_value = 0.0

    # Links 
    nds.my_link(color, 0, principled, 0)
    nds.my_link(noise, 0, curve, 1)
    nds.my_link(curve, 0, principled, 21)

    # Output ---------------------------------------------------------------------

    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (x, y)

    # Links
    nds.my_link(principled, 0, output, 0)


class MESH_OT_sphere_ring(AddObjectHelper, bpy.types.Operator):
    bl_idname = "mesh.sphere_ring"
    bl_label = "Sphere rings"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        if context.active_object is None:
            self.report({'ERROR'}, "Object have to be selected!")
            return {'FINISHED'}

        src_obj = context.active_object

        location = context.active_object.location
        radius = context.active_object['radius']

        me = bpy.data.meshes.new("Ring")

        bm = bmesh.new()

        bmesh.ops.create_circle(bm, radius=(radius + 3), segments=50)
        bmesh.ops.create_circle(bm, radius=(radius + 8), segments=50)

        ret = bmesh.ops.bridge_loops(bm, edges=bm.edges)
        bm.to_mesh(me)

        object_data_add(context, me, operator=self)

        obj = context.active_object
        obj.location = location
        mesh = obj.data

        bpy.ops.object.mode_set(mode = 'OBJECT')
        ring_material(mesh)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_all(action = 'SELECT')
        obj.active_material_index = 0
        bpy.ops.object.material_slot_assign()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        obj['planet'] = src_obj

        obj['type'] = "ring"

        src_obj['ring'] = obj

        turn_off_reflection(obj)

        return {'FINISHED'}




def register():
    bpy.utils.register_class(MESH_OT_sphere_ring)


def unregister():
    bpy.utils.unregister_class(MESH_OT_sphere_ring)