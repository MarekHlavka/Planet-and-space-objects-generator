from cmath import sqrt
import bpy
import bmesh
import time
from mathutils import Vector
from ..sphere import plain_object
from ..ui.planet_panel import get_object_name

waterable = [
    "Test"
]

def midpoint(a, b):
    
    mid_x = (a.x + b.x) / 2
    mid_y = (a.y + b.y) / 2
    mid_z = (a.z + b.z) / 2
    return Vector((mid_x, mid_y, mid_z))

def verts_dst(a, b):
    dst_x = (b.x - a.x)**2
    dst_y = (b.y - a.y)**2
    dst_z = (b.z - a.z)**2
    
    return (dst_x + dst_y + dst_z)**1/2

def reposition_to_midpoint(a, b, x):

    old_dst = plain_object.plain_3D_object.distance_to_center(None, x)
    x = midpoint(a, b)
    new_dst = plain_object.plain_3D_object.distance_to_center(None, x)

    return plain_object.plain_3D_object.change_height(None, x, old_dst/new_dst, None)

def sort_water_chunks(bm, indexes):
    pass

def separate_water_chunks(bm, indexes):
    pass

def water_edges(mesh, radius):

    print("Hello")
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_mode(type="VERT")
    bpy.ops.mesh.select_all(action = 'DESELECT')

    cnt = 0
    border_indexes = []
    bm = bmesh.from_edit_mesh(mesh)

    start = time.time()
    
    for vert in bm.verts:
        dst = plain_object.plain_3D_object.distance_to_center(None, vert.co)
        if dst <= radius + 0.05:
            cnt = cnt + 1

            vert_other = []
            for e in vert.link_edges:
                v = e.other_vert(vert)
                vert_other.append(v)
            
            check_water = False
            check_land = False
            for v in vert_other:
                if plain_object.plain_3D_object.distance_to_center(None, v.co) > radius + 0.0005:
                    check_land = True  
                else:
                    check_water = True


            if check_land and check_water:
                border_indexes.append(vert.index)
            # Check for border

    # --------------------------------------------------------------------------------------------------------
    # Delete redundant verts in water border
    # --------------------------------------------------------------------------------------------------------
   
    for vert in bm.verts:
        if vert.index not in border_indexes:
            continue
        
        # Get linked verts
        vert_other = []
        for e in vert.link_edges:
            v = e.other_vert(vert)
            vert_other.append(v)
        
        # Get linked border verts
        other_border = []
        for e in vert_other:
            if e.index in border_indexes:
                other_border.append(e)

        if len(other_border) == 1:
            border_indexes.remove(vert.index)
            continue

        # Check for redundant border verts
        connected_others = []
        for v in other_border:
            for e in v.link_edges:
                other_v = e.other_vert(v)
                if other_v in other_border and v not in connected_others:
                    connected_others.append(v)

        if len(other_border) == len(connected_others):
            border_indexes.remove(vert.index)
            continue


    for vert in bm.verts:
        if vert.index not in border_indexes:
            continue
        # Get linked verts
        vert_other = []
        for e in vert.link_edges:
            v = e.other_vert(vert)
            vert_other.append(v)
        
        # Get linked border verts
        other_border = []
        for e in vert_other:
            if e.index in border_indexes:
                other_border.append(e)
        if len(other_border) >= 2:
            vert.co = reposition_to_midpoint(other_border[0].co, other_border[1].co, vert.co)
    

        


    # --------------------------------------------------------------------------------------------------------
    # Recalculate positions of neighbors
    # --------------------------------------------------------------------------------------------------------
    for vert in bm.verts:
        if vert.index not in border_indexes:
            continue

        neigh_verts = []
        for e in vert.link_edges:
            other_vert = e.other_vert(vert)
            other_vert.select = True
            neigh_verts.append(other_vert)

        avg_dst = 0
        for neigh in neigh_verts:
            avg_dst = avg_dst + verts_dst(vert.co, neigh.co)

        avg_dst = avg_dst / len(neigh_verts)
        print(len(neigh_verts))

        for neigh in neigh_verts:
            dst = verts_dst(vert.co, neigh.co)
            if dst >= 1.5 * avg_dst:
                neigh.co = reposition_to_midpoint(midpoint(neigh.co, midpoint(neigh.co, vert.co)), neigh.co, neigh.co)
           
    
    bpy.ops.object.mode_set(mode = 'OBJECT')
    for vert in mesh.vertices:
        if vert.index in border_indexes:
            vert.select = True

    end = (time.time() - start)
    print("Time = ", end)
    


class OBJECT_OT_smooth_edges(bpy.types.Operator):
    bl_idname = "mesh.smooth_edges"
    bl_label = "Smoothens edges of water"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        obj = context.active_object
        mesh = obj.data

        if get_object_name(obj) in waterable:
            radius = obj['radius']
            water_edges(mesh, radius)

        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_smooth_edges)
    

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_smooth_edges)