from email.policy import default
import bpy
import bpy_extras
from ..sphere import plain_object
from .water_border import water_edges
from bpy_extras.object_utils import object_data_add, AddObjectHelper

def add_plain_sphere(self, context, levels, radius, noise, ocean_level,
seed, continents, water_amount, terrain_height):
    cube = plain_object.plain_3D_object(1)
    mesh = bpy.data.meshes.new(name="Test")
    cube.resize(levels)
    cube.project_to_sphere(radius)
    if(noise):
        cube.simple_noise(ocean_level, seed, continents, water_amount, terrain_height)
        #context.object.modifiers.new("idk", "SUBSURF")
    
    mesh.from_pydata(cube.vertices, cube.edges, cube.faces)
    object_data_add(context, mesh, operator=self)
    mesh = context.object.data
    
    for f in mesh.polygons:
       f.use_smooth = True

    return mesh.vertices

    
        
class MESH_OT_plain_sphere(bpy.types.Operator, AddObjectHelper):
    """Add plain sphere"""
    bl_idname = "mesh.plain_sphere"
    bl_label = "Default Planet"
    bl_options = {'REGISTER', 'UNDO'}

    detail_level: bpy.props.IntProperty(
        name="Level of detail",
        description="Determines how many faces is in the mesh",
        default = 30,
        min = 0,
        soft_max = 100,
        max = 1000
    )

    radius: bpy.props.FloatProperty(
        name="Radius",
        description="Radius of planet",
        default = 10.0,
        min = 0.1,
        soft_max = 100
    )

    noise: bpy.props.BoolProperty(
        name="Noise",
        description="noise",
        default = True
    )

    seed: bpy.props.FloatProperty(
        name="Seed",
        default = 1
    )

    continents: bpy.props.FloatProperty(
        name="Continets spread",
        default = 1
    )

    water_amount: bpy.props.FloatProperty(
        name="Amount of water",
        default = 0.4,
        min = 0.0,
        max = 1.0
    )

    terrain_factor: bpy.props.FloatProperty(
        name="Terrain height",
        default = 1.0,
        min = 0.0
    )

    def execute(self, context):

        if self.water_amount < -self.radius :
            self.water_amount = -self.radius

        '''
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas: # iterate through areas in current screen
                if area.type == 'VIEW_3D':
                    for space in area.spaces: # iterate through spaces in current VIEW_3D area
                        if space.type == 'VIEW_3D': # check if space is a 3D view
                            space.shading.type = 'RENDERED'
        '''

        verts = add_plain_sphere(self, context, self.detail_level, self.radius,
        self.noise, 1, self.seed, self.continents,
        self.water_amount, self.terrain_factor)

        context.active_object['colorable'] = True

        context.active_object['waterable'] = True

        context.active_object['radius'] = self.radius

        context.active_object['type'] = "planet"

        context.active_object['subtype'] = "plain"

        context.active_object['ring'] = None

        context.active_object['clouds'] = None

        context.active_object['water'] = self.water_amount

        # context.active_object['my_vertices'] = verts

        return {'FINISHED'}

def add_operator(self, context):
    self.layout.operator(MESH_OT_plain_sphere.bl_idname)

def register():
    bpy.utils.register_class(MESH_OT_plain_sphere)
    bpy.types.VIEW3D_MT_object.append(add_operator)
    #bpy.types.VIEW3D_MT_mesh_add.append(add_operator)

def unregister():
    bpy.utils.unregister_class(MESH_OT_plain_sphere)
    bpy.types.VIEW3D_MT_object.remove(add_operator)
    #bpy.types.VIEW3D_MT_mesh_add.remove(add_operator)